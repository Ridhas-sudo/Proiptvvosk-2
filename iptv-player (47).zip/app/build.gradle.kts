import java.net.URL
import java.net.HttpURLConnection
import java.net.CookieManager
import java.net.CookieHandler
import java.net.HttpCookie
import java.util.zip.ZipFile
import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example"
    compileSdk = 34

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    defaultConfig {
        applicationId = "com.aistudio.proiptv.kxypt"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }

        // Load environment variables from .env or .env.example
        val envProps = Properties()
        val envFile = File(rootDir, ".env")
        val envExampleFile = File(rootDir, ".env.example")
        if (envFile.exists()) {
            val stream = envFile.inputStream()
            envProps.load(stream)
            stream.close()
        } else if (envExampleFile.exists()) {
            val stream = envExampleFile.inputStream()
            envProps.load(stream)
            stream.close()
        }
        
        val nodeEnv = envProps.getProperty("NODE_ENV") ?: "production"
        val geminiApiKey = envProps.getProperty("GEMINI_API_KEY") ?: ""
        
        buildConfigField("String", "NODE_ENV", "\"$nodeEnv\"")
        buildConfigField("String", "GEMINI_API_KEY", "\"$geminiApiKey\"")

        ndk {
            abiFilters.addAll(listOf("arm64-v8a", "armeabi-v7a", "x86_64", "x86"))
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.13"
    }
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")

    // Compose
    implementation("androidx.compose.ui:ui:1.6.1")
    implementation("androidx.compose.ui:ui-graphics:1.6.1")
    implementation("androidx.compose.ui:ui-tooling-preview:1.6.1")
    implementation("androidx.compose.material3:material3:1.2.0")
    implementation("androidx.compose.material:material-icons-extended:1.6.1")

    // Media3 (ExoPlayer)
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("androidx.media3:media3-common:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.4.1")
    implementation("androidx.media3:media3-exoplayer-rtsp:1.4.1")
    implementation("androidx.media3:media3-datasource-okhttp:1.4.1")

    // Networking & Serialization
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:okhttp-urlconnection:4.12.0")
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")
    
    // Coil (Image Loading)
    implementation("io.coil-kt:coil-compose:2.6.0")

    // ML Kit Translation & Language ID & Text Recognition
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.7.3")

    // Vosk Speech Recognition
    implementation("com.alphacephei:vosk-android:0.3.47")

    // Tests
    testImplementation("junit:junit:4.13.2")
    testImplementation("androidx.test:core:1.5.0")
    testImplementation("org.robolectric:robolectric:4.11.1")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}

tasks.register("copyApkToRoot") {
    dependsOn("assembleDebug")
    doLast {
        val apkFile = layout.buildDirectory.file("outputs/apk/debug/app-debug.apk").get().asFile
        val rootDestFile = File(rootDir, "Pro_IPTV.apk")
        val platformDestFile = File(rootDir, ".build-outputs/app-debug.apk")
        
        if (apkFile.exists()) {
            rootDestFile.parentFile?.mkdirs()
            apkFile.copyTo(rootDestFile, overwrite = true)
            platformDestFile.parentFile?.mkdirs()
            apkFile.copyTo(platformDestFile, overwrite = true)
        }
    }
}

afterEvaluate {
    tasks.named("assembleDebug") {
        finalizedBy("copyApkToRoot")
    }
}



