package com.example.data

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

class PortalRepository(
    private val context: Context,
    private val portalUrl: String,
    private val macAddress: String,
    private val okHttpClient: OkHttpClient = OkHttpClient()
) {
    private var token: String = ""
    private val userMac: String get() = macAddress.trim().uppercase()

    suspend fun handshake(): Boolean = withContext(Dispatchers.IO) {
        val cleanUrl = cleanPortalBase(portalUrl)
        val endpoints = listOf(
            "${cleanUrl}api/mag.php?action=handshake&type=stb&token=&JsHttpRequest=1-xml",
            "${cleanUrl}server/load.php?action=handshake&type=stb&token=&JsHttpRequest=1-xml",
            "${cleanUrl}load.php?action=handshake&type=stb&token=&JsHttpRequest=1-xml"
        )
        for (handshakeUrl in endpoints) {
            val request = Request.Builder()
                .url(handshakeUrl)
                .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                .header("Cookie", "mac=$userMac; stb_lang=fr; timezone=Europe/Paris")
                .header("Referer", "${cleanUrl}c/")
                .get()
                .build()

            try {
                okHttpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string() ?: ""
                    Log.d("PORTAL", "Handshake response: $body")
                    if (response.isSuccessful && body.isNotEmpty()) {
                        val cleaned = cleanStalkerJson(body)
                        val json = JSONObject(cleaned)
                        val jsObj = json.optJSONObject("js")
                        val extracted = jsObj?.optString("token") ?: json.optString("token").ifEmpty { json.optString("js") }
                        if (extracted.isNotEmpty()) {
                            token = extracted
                            return@withContext true
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("PORTAL", "Handshake failed on $handshakeUrl: ${e.message}")
            }
        }
        return@withContext false
    }

    suspend fun getStreamUrl(channelId: String): StreamResult = withContext(Dispatchers.IO) {
        if (token.isEmpty()) {
            handshake()
        }

        val cleanUrl = cleanPortalBase(portalUrl)
        val cleanCmd = channelId.replace(Regex("^(ffmpeg|ffrt|ffrt2|auto|standalone)\\s+", RegexOption.IGNORE_CASE), "").trim()
        val encodedCmd = URLEncoder.encode(cleanCmd, "UTF-8")

        val endpointsToTry = listOf(
            "${cleanUrl}api/mag.php?action=create_link&type=itv&cmd=$encodedCmd&JsHttpRequest=1-xml",
            "${cleanUrl}server/load.php?action=create_link&type=itv&cmd=$encodedCmd&JsHttpRequest=1-xml",
            "${cleanUrl}load.php?action=create_link&type=itv&cmd=$encodedCmd&JsHttpRequest=1-xml"
        )

        var finalUrl: String? = null
        var shouldRetryHandshake = false

        for (createLinkUrl in endpointsToTry) {
            val request = Request.Builder()
                .url(createLinkUrl)
                .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                .header("Cookie", "mac=$userMac; stb_lang=fr; timezone=Europe/Paris")
                .header("Referer", "${cleanUrl}c/")
                .header("Authorization", "Bearer $token")
                .get()
                .build()

            try {
                val response = okHttpClient.newCall(request).execute()
                val responseStr = response.body?.string() ?: ""
                response.close()
                Log.d("PORTAL", "create_link raw: $responseStr")

                if (responseStr.contains("limit", ignoreCase = true) || responseStr.contains("expired", ignoreCase = true)) {
                    shouldRetryHandshake = true
                } else if (response.isSuccessful && responseStr.isNotEmpty()) {
                    val cleaned = cleanStalkerJson(responseStr)
                    val json = try { JSONObject(cleaned) } catch (e: Exception) { null }
                    if (json != null) {
                        val jsObj = json.optJSONObject("js")
                        var link = jsObj?.optString("url")?.ifEmpty { jsObj.optString("cmd") }
                            ?: json.optString("url").ifEmpty { json.optString("cmd") }

                        if (link.isNullOrEmpty() && jsObj != null) {
                            link = jsObj.optString("url")
                        }

                        if (link.isNullOrEmpty() && json.has("js") && json.get("js") is String) {
                            link = json.getString("js")
                        }

                        if (!link.isNullOrEmpty()) {
                            var resolvedLink = link.trim()
                            if (resolvedLink.startsWith("ffmpeg ")) {
                                resolvedLink = resolvedLink.substringAfter("ffmpeg ").trim()
                            }
                            if (resolvedLink.startsWith("http://") || resolvedLink.startsWith("https://")) {
                                finalUrl = resolvedLink
                                break
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("PORTAL", "create_link error on $createLinkUrl: ${e.message}")
            }
        }

        if (shouldRetryHandshake || finalUrl == null) {
            withContext(Dispatchers.Main) {
                Toast.makeText(context, "Lien expiré, reconnexion...", Toast.LENGTH_SHORT).show()
            }
            // Re-do handshake
            val hsOk = handshake()
            if (hsOk) {
                // Retry create_link once
                val retryUrl = "${cleanUrl}api/mag.php?action=create_link&type=itv&cmd=$encodedCmd&JsHttpRequest=1-xml"
                val request = Request.Builder()
                    .url(retryUrl)
                    .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                    .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                    .header("Cookie", "mac=$userMac; stb_lang=fr; timezone=Europe/Paris")
                    .header("Referer", "${cleanUrl}c/")
                    .header("Authorization", "Bearer $token")
                    .get()
                    .build()

                try {
                    okHttpClient.newCall(request).execute().use { response ->
                        val responseStr = response.body?.string() ?: ""
                        Log.d("PORTAL", "create_link raw: $responseStr")
                        if (response.isSuccessful && responseStr.isNotEmpty()) {
                            val cleaned = cleanStalkerJson(responseStr)
                            val json = try { JSONObject(cleaned) } catch (e: Exception) { null }
                            if (json != null) {
                                val jsObj = json.optJSONObject("js")
                                var link = jsObj?.optString("url")?.ifEmpty { jsObj.optString("cmd") }
                                    ?: json.optString("url").ifEmpty { json.optString("cmd") }
                                if (link.isNullOrEmpty() && json.has("js") && json.get("js") is String) {
                                    link = json.getString("js")
                                }
                                if (!link.isNullOrEmpty()) {
                                    var resolvedLink = link.trim()
                                    if (resolvedLink.startsWith("ffmpeg ")) {
                                        resolvedLink = resolvedLink.substringAfter("ffmpeg ").trim()
                                    }
                                    if (resolvedLink.startsWith("http://") || resolvedLink.startsWith("https://")) {
                                        finalUrl = resolvedLink
                                    }
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e("PORTAL", "Retry create_link error: ${e.message}")
                }
            }
        }

        val effectiveFinalUrl = finalUrl ?: cleanCmd
        Log.d("PORTAL", "final URL: $effectiveFinalUrl")

        val serverReferer = if (cleanUrl.endsWith("/")) cleanUrl else "$cleanUrl/"
        val exoHeaders = mapOf(
            "User-Agent" to "VLC/3.0.18",
            "Referer" to serverReferer
        )

        return@withContext StreamResult(
            url = effectiveFinalUrl,
            headers = exoHeaders
        )
    }

    private fun cleanPortalBase(url: String): String {
        var base = url.trim()
        if (base.contains("/stalker_portal/c/")) {
            return base.substringBefore("/stalker_portal/c/") + "/stalker_portal/"
        }
        if (base.contains("/c/")) {
            return base.substringBefore("/c/") + "/"
        }
        if (base.endsWith("/server/load.php")) {
            return base.substringBefore("/server/load.php") + "/"
        }
        if (!base.endsWith("/")) {
            base += "/"
        }
        return base
    }

    data class StreamResult(
        val url: String,
        val headers: Map<String, String>
    )
}
