package com.example.data

import android.util.Log
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class StalkerAuthManager {
    private var currentToken: String = ""
    private var currentPortalUrl: String = ""
    private var currentMacAddress: String = ""
    private var currentEndpointFileName: String = "server/load.php"
    private val lock = Any()

    companion object {
        private const val TAG = "StalkerAuthManager"
        const val DEFAULT_USER_AGENT = "Mozilla/5.0 QtWebEngine/5.15.2"
    }

    fun init(portalUrl: String, macAddress: String) {
        synchronized(lock) {
            this.currentPortalUrl = sanitizeUrl(portalUrl)
            this.currentMacAddress = formatMacAddress(macAddress)
            this.currentToken = ""
            this.currentEndpointFileName = "server/load.php"
            Log.d(TAG, "Initialized with Portal: $currentPortalUrl, MAC: $currentMacAddress")
        }
    }

    fun getToken(): String = synchronized(lock) { currentToken }
    fun getPortalUrl(): String = synchronized(lock) { currentPortalUrl }
    fun getMacAddress(): String = synchronized(lock) { currentMacAddress }
    fun getEndpointFileName(): String = synchronized(lock) { currentEndpointFileName }

    fun sanitizeUrl(url: String): String {
        var clean = url.trim()
        if (clean.endsWith("/c/")) {
            clean = clean.substring(0, clean.length - 2)
        }
        if (clean.endsWith("/stalker_portal/c/")) {
            clean = clean.substring(0, clean.length - 17)
        }
        if (!clean.endsWith("/")) {
            clean += "/"
        }
        return clean
    }

    fun formatMacAddress(mac: String): String {
        val cleaned = mac.replace(":", "").replace("-", "").trim().uppercase()
        val builder = StringBuilder()
        for (i in cleaned.indices) {
            builder.append(cleaned[i])
            if (i % 2 == 1 && i < cleaned.length - 1) {
                builder.append(":")
            }
        }
        return builder.toString()
    }

    /**
     * Exact 4-step Handshake/Authentication flow per Stalker Portal specification
     */
    fun performFullAuthSequence(): String {
        var portal = ""
        var mac = ""
        synchronized(lock) {
            portal = currentPortalUrl
            mac = currentMacAddress
        }

        if (portal.isEmpty() || mac.isEmpty()) {
            Log.e(TAG, "Cannot authenticate: Portal URL or MAC address is empty.")
            return ""
        }

        val client = createBaseClient()

        // Step 1 & 2: Handshake
        val token = handshake(client, portal, mac)
        if (token.isEmpty()) {
            // Try fallback load balance if URL fails
            val alternativePortal = if (portal.contains("/stalker_portal/")) {
                portal.replace("/stalker_portal/", "/")
            } else if (!portal.contains("/stalker_portal/c/") && portal.endsWith("/c/")) {
                portal.replace("/c/", "/stalker_portal/c/")
            } else {
                ""
            }
            if (alternativePortal.isNotEmpty()) {
                Log.d(TAG, "Handshake failed on main URL, trying load balance alternative: $alternativePortal")
                val fallbackToken = handshake(client, alternativePortal, mac)
                if (fallbackToken.isNotEmpty()) {
                    synchronized(lock) {
                        currentPortalUrl = alternativePortal
                        currentToken = fallbackToken
                    }
                    activateProfile(client, alternativePortal, mac, fallbackToken)
                    return fallbackToken
                }
            }
            return ""
        }

        synchronized(lock) {
            currentToken = token
        }

        // Step 3: Activate profile
        val profileActivated = activateProfile(client, portal, mac, token)
        if (!profileActivated) {
            Log.w(TAG, "Profile activation returned non-success or failure; continuing with token.")
        }

        return token
    }

    private fun handshake(client: OkHttpClient, portalUrl: String, mac: String): String {
        val cleanBase = if (portalUrl.endsWith("/")) portalUrl else "$portalUrl/"
        val endpointsToTry = if (portalUrl.contains("portal.php")) {
            listOf("portal.php", "server/load.php")
        } else {
            listOf("server/load.php", "portal.php")
        }

        for (epFilename in endpointsToTry) {
            val endpoint = "${cleanBase}${epFilename}"
            val url = "$endpoint?type=stb&action=handshake&token=&JsHttpRequest=1-xml"
            Log.d(TAG, "--> Handshake Step 1: GET $url")

            val deviceFields = generateStalkerDeviceFields(mac)
            val devId = deviceFields["device_id"] ?: ""
            var devId2 = deviceFields["device_id2"] ?: ""
            if (portalUrl.contains("deirnet.ps", ignoreCase = true) || endpoint.contains("deirnet.ps", ignoreCase = true)) {
                devId2 = ""
            }
            val sig = deviceFields["signature"] ?: ""
            val serial = deviceFields["serial_number"] ?: ""

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", DEFAULT_USER_AGENT)
                .header("Referer", portalUrl)
                .header("Cookie", "mac=${URLEncoder.encode(mac, "UTF-8")}; stb_lang=en; timezone=Europe/Kiev")
                .header("X-User-Card", "mac=$mac; stb_lang=en; timezone=Europe/Kiev; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial")
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    val bodyStr = response.body?.string() ?: ""
                    Log.d(TAG, "<-- Handshake Response Code: ${response.code} for $epFilename")
                    if (!response.isSuccessful) return@use

                    val cleaned = cleanStalkerJson(bodyStr)
                    val json = JSONObject(cleaned)
                    var token = ""
                    if (json.has("js")) {
                        val jsObj = json.optJSONObject("js")
                        if (jsObj != null) {
                            token = jsObj.optString("token")
                        } else {
                            token = json.optString("js")
                        }
                    }
                    if (token.isEmpty() && json.has("token")) {
                        token = json.optString("token")
                    }
                    if (token.isEmpty() && json.has("result")) {
                        val resObj = json.optJSONObject("result")
                        if (resObj != null) {
                            token = resObj.optString("token")
                        } else {
                            token = json.optString("result")
                        }
                    }
                    if (token.isNotEmpty()) {
                        Log.d(TAG, "Handshake token parsed: $token using endpoint $epFilename")
                        synchronized(lock) {
                            currentEndpointFileName = epFilename
                        }
                        return token
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Handshake failed on $epFilename: ${e.message}")
            }
        }
        return ""
    }

    private fun activateProfile(client: OkHttpClient, portalUrl: String, mac: String, token: String): Boolean {
        val endpoint = if (portalUrl.contains("server/load.php")) {
            portalUrl
        } else {
            "${portalUrl}server/load.php"
        }
        // Action: get_profile
        val url = "$endpoint?type=stb&action=get_profile&JsHttpRequest=1-xml"
        Log.d(TAG, "--> Activation Step 3: GET $url")

        val deviceFields = generateStalkerDeviceFields(mac)
        val devId = deviceFields["device_id"] ?: ""
        var devId2 = deviceFields["device_id2"] ?: ""
        if (portalUrl.contains("deirnet.ps", ignoreCase = true) || endpoint.contains("deirnet.ps", ignoreCase = true)) {
            devId2 = ""
        }
        val sig = deviceFields["signature"] ?: ""
        val serial = deviceFields["serial_number"] ?: ""

        val request = Request.Builder()
            .url(url)
            .header("User-Agent", DEFAULT_USER_AGENT)
            .header("Referer", portalUrl)
            .header("Authorization", "Bearer $token")
            .header("Cookie", "mac=${URLEncoder.encode(mac, "UTF-8")}; stb_lang=en; timezone=Europe/Kiev")
            .header("X-User-Card", "mac=$mac; stb_lang=en; timezone=Europe/Kiev; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial")
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: ""
                Log.d(TAG, "<-- Profile Activation Code: ${response.code}")
                if (!response.isSuccessful) return false

                val cleaned = cleanStalkerJson(bodyStr)
                if (cleaned.contains("Your STB is blocked")) {
                    Log.e(TAG, "CRITICAL ERROR: Your STB is blocked. MAC not authorized. Contact provider")
                }
                val json = JSONObject(cleaned)
                val jsVal = json.opt("js") ?: json.opt("result")
                if (jsVal != null) {
                    Log.d(TAG, "Profile activated successfully!")
                    return true
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Profile activation request failed", e)
        }
        return false
    }

    private fun createBaseClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Builds an OkHttpClient configured with Stalker custom headers, CookieJar, 
     * Logging interceptor, and automatic token re-handshake on authorization failure.
     */
    fun createStalkerOkHttpClient(): OkHttpClient {
        // Built-in simple Logging Interceptor to print full requests and responses without external dependencies
        val loggingInterceptor = Interceptor { chain ->
            val request = chain.request()
            val url = request.url.toString()
            Log.d("STALKER_HTTP_RAW", "--> REQUEST: ${request.method} $url")
            request.headers.forEach { pair ->
                Log.d("STALKER_HTTP_RAW", "Header: ${pair.first} = ${pair.second}")
            }
            
            val response = chain.proceed(request)
            Log.d("STALKER_HTTP_RAW", "<-- RESPONSE: ${response.code} for $url")
            response
        }

        return OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .addInterceptor(loggingInterceptor)
            .addInterceptor(Interceptor { chain ->
                var request = chain.request()
                var currentTokenCopy = getToken()
                var portal = getPortalUrl()
                var mac = getMacAddress()

                // Inject auth headers if they are missing
                val requestBuilder = request.newBuilder()
                requestBuilder.header("User-Agent", DEFAULT_USER_AGENT)
                if (portal.isNotEmpty()) {
                    requestBuilder.header("Referer", portal)
                }
                if (mac.isNotEmpty()) {
                    val deviceFields = generateStalkerDeviceFields(mac)
                    val devId = deviceFields["device_id"] ?: ""
                    val devId2 = deviceFields["device_id2"] ?: ""
                    val sig = deviceFields["signature"] ?: ""
                    val serial = deviceFields["serial_number"] ?: ""
                    requestBuilder.header("Cookie", "mac=${URLEncoder.encode(mac, "UTF-8")}; stb_lang=en; timezone=Europe/Kiev; token=$currentTokenCopy")
                    requestBuilder.header("X-User-Card", "mac=$mac; stb_lang=en; timezone=Europe/Kiev; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial")
                }
                if (currentTokenCopy.isNotEmpty()) {
                    requestBuilder.header("Authorization", "Bearer $currentTokenCopy")
                }

                request = requestBuilder.build()
                var response = chain.proceed(request)

                // Step 4: Token expires fast. Check if body or response indicates Authorization failed
                val isAuthFailed = response.code == 401 || response.code == 403 || responseBodyIndicatesAuthFailure(response)
                if (isAuthFailed) {
                    Log.w(TAG, "Authorization failed detected (Code: ${response.code}). Re-handshaking and retrying...")
                    response.close()

                    // Synchronized re-handshake
                    val newToken = performFullAuthSequence()
                    if (newToken.isNotEmpty()) {
                        val retryRequestBuilder = request.newBuilder()
                        retryRequestBuilder.header("Authorization", "Bearer $newToken")
                        if (mac.isNotEmpty()) {
                            val deviceFields = generateStalkerDeviceFields(mac)
                            val devId = deviceFields["device_id"] ?: ""
                            val devId2 = deviceFields["device_id2"] ?: ""
                            val sig = deviceFields["signature"] ?: ""
                            val serial = deviceFields["serial_number"] ?: ""
                            retryRequestBuilder.header("Cookie", "mac=${URLEncoder.encode(mac, "UTF-8")}; stb_lang=en; timezone=Europe/Kiev; token=$newToken")
                            retryRequestBuilder.header("X-User-Card", "mac=$mac; stb_lang=en; timezone=Europe/Kiev; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial")
                        }
                        response = chain.proceed(retryRequestBuilder.build())
                    }
                }

                response
            })
            .build()
    }

    private fun responseBodyIndicatesAuthFailure(response: Response): Boolean {
        val peekBody = response.peekBody(2048).string()
        return peekBody.contains("Authorization failed", ignoreCase = true) || 
               peekBody.contains("error\":\"Authorization failed", ignoreCase = true)
    }
}
