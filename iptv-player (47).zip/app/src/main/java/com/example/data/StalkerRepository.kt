package com.example.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.sync.withPermit
import okhttp3.Request
import okhttp3.OkHttpClient
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object StalkerSeriesCache {
    val cache = java.util.concurrent.ConcurrentHashMap<String, StalkerShowGroup>()
}

data class StalkerSeasonInfo(
    val seasonNumber: String,
    val cmd: String,
    val seriesList: List<Int>
)

data class StalkerShowGroup(
    val showId: String,
    val name: String,
    val oName: String,
    val description: String,
    val logoUrl: String,
    val categoryId: String,
    val year: String,
    val seasons: List<StalkerSeasonInfo>
)

data class RawStalkerSeriesItem(
    val id: String,
    val name: String,
    val cmd: String,
    val logo: String,
    val categoryId: String,
    val resolvedCategoryName: String,
    val oName: String,
    val description: String,
    val year: String,
    val seriesList: List<Int>
)

data class EpgFoxBleu(
    val ch_id: String, // "13847"
    val start_timestamp: Long, // 1785377100
    val stop_timestamp: Long
)

class StalkerRepository(private val context: Context, private val apiService: ApiService) {

    private val db = AppDatabase.getDatabase(context)

    private data class ResolvedPortalPath(
        val baseUrl: String, // guaranteed to end with '/'
        val endpointFile: String // e.g. "portal.php" or "server/load.php"
    )

    private fun resolveStalkerPath(portalUrl: String, macAddress: String = "", endpointPathHint: String = ""): ResolvedPortalPath {
        val isPortalPhpCandidate = portalUrl.contains("portal.php", ignoreCase = true)
        val defaultEp = if (isPortalPhpCandidate) "portal.php" else "server/load.php"
        val cached = apiService.getCachedHandshakeResult(portalUrl, macAddress)
        if (cached != null && cached.resolvedUrl.isNotEmpty()) {
            val resolvedBase = if (cached.resolvedUrl.endsWith("/")) cached.resolvedUrl else "${cached.resolvedUrl}/"
            val epFile = if (endpointPathHint.isNotEmpty() && endpointPathHint != "server/load.php") {
                endpointPathHint
            } else if (isPortalPhpCandidate) {
                "portal.php"
            } else {
                cached.endpointPath
            }
            return ResolvedPortalPath(resolvedBase, epFile)
        }
        var clean = portalUrl.trim()
        if (clean.endsWith("server/load.php")) clean = clean.removeSuffix("server/load.php")
        if (clean.endsWith("portal.php")) clean = clean.removeSuffix("portal.php")
        if (!clean.endsWith("/")) clean = "$clean/"
        val epFile = if (endpointPathHint.isNotEmpty()) endpointPathHint else defaultEp
        return ResolvedPortalPath(clean, epFile)
    }

    private fun getEndpointFileName(portalUrl: String, macAddress: String = ""): String {
        return resolveStalkerPath(portalUrl, macAddress).endpointFile
    }

    private fun hasValidNonGenericCategories(categories: Map<String, String>): Boolean {
        return categories.count { (id, title) ->
            val cleanId = id.trim()
            cleanId != "*" && cleanId.lowercase() != "all" && cleanId != "0" &&
                !isGenericCategory(title)
        } > 0
    }

    private fun fetchStalkerCategories(
        client: okhttp3.OkHttpClient,
        cleanUrl: String,
        token: String,
        macAddress: String,
        actionType: String, // "vod" or "series"
        endpointPath: String = "server/load.php"
    ): Map<String, String> {
        val categories = LinkedHashMap<String, String>()
        val pathInfo = resolveStalkerPath(cleanUrl, macAddress, endpointPath)
        val baseUrl = pathInfo.baseUrl
        val activeEndpoint = pathInfo.endpointFile
        val endpointsToTry = listOf(activeEndpoint, if (activeEndpoint == "portal.php") "server/load.php" else "portal.php").distinct()

        // Stalker portals can use "vod", "video", or "series" for content types
        val typesToTry = if (actionType.equals("series", ignoreCase = true) || actionType.equals("tv_series", ignoreCase = true)) {
            listOf("tv_series", "series", "video", "vod")
        } else {
            listOf("vod", "video")
        }

        // Priority order of actions: Try get_categories first (main categories), then genres/subcategories to merge all available
        val actionsToTry = if (actionType.equals("series", ignoreCase = true) || actionType.equals("tv_series", ignoreCase = true)) {
            listOf("get_categories", "get_series_categories", "get_genres", "get_series_genres", "get_subcategories", "get_categories_list", "get_genres_list")
        } else {
            listOf("get_categories", "get_genres", "get_subcategories", "get_categories_list", "get_genres_list", "get_categories&force_show_all=1", "get_genres&force_show_all=1")
        }
        
        for (ep in endpointsToTry) {
            for (t in typesToTry) {
                var foundAnyForThisType = false
                for (action in actionsToTry) {
                    val url = "${baseUrl}${ep}?type=$t&action=$action&token=$token&JsHttpRequest=1-xml"
                    val requestBuilder = Request.Builder().url(url)
                    addStalkerHeaders(requestBuilder, macAddress, baseUrl, token)
                    val request = requestBuilder.build()
                    
                    try {
                        Log.d("STALKER_DEBUG", "--> [STALKER CATEGORIES REQUEST] URL: $url")
                        client.newCall(request).execute().use { response ->
                            val body = response.body?.string() ?: ""
                            Log.d("STALKER_DEBUG", "<-- [STALKER CATEGORIES RESPONSE] URL: $url, HTTP: ${response.code}")
                            Log.d("STALKER_DEBUG", "Body snippet: ${if (body.length > 800) body.take(800) + "..." else body}")
                            
                            if (response.isSuccessful) {
                                val cleaned = cleanStalkerJson(body)
                                if (cleaned.isNotEmpty()) {
                                    val beforeSize = categories.size
                                    if (cleaned.startsWith("[")) {
                                        val jsArr = JSONArray(cleaned)
                                        parseCategoriesJsonArray(jsArr, categories)
                                    } else if (cleaned.startsWith("{")) {
                                        val json = JSONObject(cleaned)
                                        parseCategoriesFromJsonObject(json, categories)
                                    }
                                    if (categories.size > beforeSize) {
                                        foundAnyForThisType = true
                                    }
                                }
                            }
                            Unit
                        }
                    } catch (e: Exception) {
                        Log.e("STALKER_DEBUG", "Failed to fetch categories with endpoint=$ep, type=$t, action=$action: ${e.message}")
                    }
                }

                // Interroger également les sous-catégories (genres) pour chaque catégorie parente trouvée
                val parentIds = categories.keys.toList()
                for (parentId in parentIds) {
                    val subActions = listOf("get_genres&category=$parentId", "get_genres&category_id=$parentId", "get_subcategories&category=$parentId")
                    for (subAction in subActions) {
                        val subUrl = "${baseUrl}${ep}?type=$t&action=$subAction&token=$token&JsHttpRequest=1-xml"
                        try {
                            val req = Request.Builder().url(subUrl).build()
                            val reqB = Request.Builder().url(subUrl)
                            addStalkerHeaders(reqB, macAddress, baseUrl, token)
                            client.newCall(reqB.build()).execute().use { response ->
                                if (response.isSuccessful) {
                                    val cleaned = cleanStalkerJson(response.body?.string() ?: "")
                                    if (cleaned.startsWith("[")) {
                                        parseCategoriesJsonArray(JSONArray(cleaned), categories)
                                    } else if (cleaned.startsWith("{")) {
                                        parseCategoriesFromJsonObject(JSONObject(cleaned), categories)
                                    }
                                }
                                Unit
                            }
                        } catch (e: Exception) {
                            // ignore
                        }
                    }
                }

                if (foundAnyForThisType && hasValidNonGenericCategories(categories)) {
                    Log.d("STALKER_DEBUG", "[STALKER CATEGORIES MATCH] Found ${categories.size} total categories/genres with endpoint=$ep, type=$t")
                    return categories
                }
            }
        }
        return categories
    }

    private fun parseCategoriesFromJsonObject(json: JSONObject, categories: MutableMap<String, String>) {
        val possibleArrayKeys = listOf("js", "result", "data", "results", "genres", "categories", "list", "items", "item", "category", "genre", "list_items", "rows")
        // 1. Try to find any known JSONArray keys in the root object
        for (key in possibleArrayKeys) {
            val arr = json.optJSONArray(key)
            if (arr != null && arr.length() > 0) {
                parseCategoriesJsonArray(arr, categories)
                return
            }
        }

        // 2. Try to find any known JSONObject keys that might contain arrays or nested objects
        for (key in possibleArrayKeys) {
            val obj = json.optJSONObject(key)
            if (obj != null) {
                // Check if this nested object itself has arrays
                for (subKey in possibleArrayKeys) {
                    val subArr = obj.optJSONArray(subKey)
                    if (subArr != null && subArr.length() > 0) {
                        parseCategoriesJsonArray(subArr, categories)
                        return
                    }
                }
                // Otherwise, parse the nested object directly
                parseCategoriesJsonObject(obj, categories)
                if (categories.isNotEmpty()) return
            }
        }

        // 3. Fallback: parse the root object directly
        parseCategoriesJsonObject(json, categories)
    }

    private fun parseCategoriesJsonArray(arr: JSONArray, outMap: MutableMap<String, String>) {
        for (i in 0 until arr.length()) {
            val item = arr.opt(i)
            if (item is JSONObject) {
                val id = item.optString("id")
                    .ifEmpty { item.optString("category_id") }
                    .ifEmpty { item.optString("genre_id") }
                    .ifEmpty { item.optString("cat_id") }
                    .ifEmpty { item.optString("id_category") }
                    .ifEmpty { item.optString("id_genre") }
                    .ifEmpty { item.optString("alias") }
                    .trim()
                val title = item.optString("title")
                    .ifEmpty { item.optString("name") }
                    .ifEmpty { item.optString("category_name") }
                    .ifEmpty { item.optString("genre_name") }
                    .ifEmpty { item.optString("category") }
                    .ifEmpty { item.optString("genre") }
                    .ifEmpty { item.optString("label") }
                    .ifEmpty { item.optString("title_en") }
                    .ifEmpty { item.optString("title_fr") }
                    .ifEmpty { item.optString("cat_name") }
                    .trim()
                if (id.isNotEmpty() && title.isNotEmpty()) {
                    outMap[id] = title
                }
            }
        }
    }

    private fun parseCategoriesJsonObject(obj: JSONObject, outMap: MutableMap<String, String>) {
        val keys = obj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val value = obj.opt(key) ?: continue
            if (value is JSONObject) {
                val id = value.optString("id")
                    .ifEmpty { value.optString("category_id") }
                    .ifEmpty { value.optString("genre_id") }
                    .ifEmpty { value.optString("cat_id") }
                    .ifEmpty { value.optString("alias") }
                    .ifEmpty { key }
                    .trim()
                val title = value.optString("title")
                    .ifEmpty { value.optString("name") }
                    .ifEmpty { value.optString("category_name") }
                    .ifEmpty { value.optString("genre_name") }
                    .ifEmpty { value.optString("category") }
                    .ifEmpty { value.optString("genre") }
                    .ifEmpty { value.optString("label") }
                    .ifEmpty { value.optString("title_en") }
                    .ifEmpty { value.optString("title_fr") }
                    .ifEmpty { value.optString("cat_name") }
                    .trim()
                if (id.isNotEmpty() && title.isNotEmpty()) {
                    outMap[id] = title
                }
            } else if (value is String || value is Number || value is Boolean) {
                val id = key.trim()
                val title = value.toString().trim()
                if (id.isNotEmpty() && title.isNotEmpty() && !id.equals("js", ignoreCase = true) && !id.equals("result", ignoreCase = true)) {
                    outMap[id] = title
                }
            }
        }
    }

    private fun isGenericCategory(name: String): Boolean {
        val lower = name.lowercase().trim()
        return lower == "all" || lower == "tout" || lower == "tous" || lower == "favoris" || lower == "favorites" || lower == "fav" || lower == "recently added" || lower == "nouveautés" || lower == "nouveauté" || lower == "stalker vod" || lower == "stalker series" || lower == "" || lower == "*" || lower == "0" || lower == "null"
    }

    private fun getDeduplicationKey(item: ChannelItem): String {
        val nameKey = item.name.lowercase().trim()
        val urlWithoutParams = item.streamUrl.substringBefore("?")
        return "$nameKey|$urlWithoutParams"
    }

    private suspend fun fetchSingleStalkerPage(
        client: okhttp3.OkHttpClient,
        cleanUrl: String,
        token: String,
        macAddress: String,
        playlistId: Long,
        actionType: String,
        type: String,
        catId: String?,
        catName: String,
        defaultGroupName: String,
        categoriesMap: Map<String, String>,
        page: Int,
        endpointPath: String = "server/load.php"
    ): List<ChannelItem> = withContext(Dispatchers.IO) {
        val pathInfo = resolveStalkerPath(cleanUrl, macAddress, endpointPath)
        val baseUrl = pathInfo.baseUrl
        val activeEndpoint = pathInfo.endpointFile
        val categoryQuery = if (catId != null) {
            "&category=$catId&category_id=$catId&genre=$catId"
        } else {
            ""
        }
        // Send both p and page parameters to guarantee compatibility with all Stalker Portal versions (v5.3+)
        val url = "${baseUrl}${activeEndpoint}?type=$actionType&action=get_ordered_list$categoryQuery&p=$page&page=$page&token=$token&JsHttpRequest=1-xml"
        val requestBuilder = Request.Builder().url(url)
        addStalkerHeaders(requestBuilder, macAddress, baseUrl, token)
        val request = requestBuilder.build()

        Log.d("STALKER_API_LOG", "[STALKER API CALL] GET ordered list: $url (Page: $page)")

        try {
            client.newCall(request).execute().use { response ->
                val responseCode = response.code
                val body = response.body?.string() ?: ""
                Log.d("STALKER_API_LOG", "[STALKER API RESPONSE] GET ordered list: $url, Code: $responseCode, Body Snippet: ${if (body.length > 500) body.take(500) + "..." else body}")

                if (!response.isSuccessful) {
                    Log.e("STALKER_DEBUG", "HTTP $responseCode fetching page $page for type=$actionType")
                    return@withContext emptyList()
                }

                val jsArray = cleanAndExtractStalkerArray(body)
                if (jsArray == null || jsArray.length() == 0) {
                    return@withContext emptyList()
                }

                val pageItems = mutableListOf<ChannelItem>()
                for (i in 0 until jsArray.length()) {
                    try {
                        val obj = jsArray.optJSONObject(i) ?: continue
                        val id = obj.optString("id")
                            .ifEmpty { obj.optString("series_id") }
                            .ifEmpty { obj.optString("movie_id") }
                            .ifEmpty { obj.optString("item_id") }
                            .ifEmpty { obj.hashCode().toString() }
                            .trim()
                        val name = obj.optString("name")
                            .ifEmpty { obj.optString("series_name") }
                            .ifEmpty { obj.optString("movie_name") }
                            .ifEmpty { obj.optString("title") }
                            .ifEmpty { obj.optString("o_name") }
                            .ifEmpty { obj.optString("original_name") }
                            .ifEmpty { obj.optString("label") }
                            .trim()
                        val cmd = obj.optString("cmd")
                            .ifEmpty { obj.optString("path") }
                            .ifEmpty { obj.optString("url") }
                            .trim()
                        val logo = obj.optString("logo")
                            .ifEmpty { obj.optString("screenshot") }
                            .ifEmpty { obj.optString("poster") }
                            .trim()

                        val categoryId = obj.optString("category_id")
                            .ifEmpty { obj.optString("genre_id") }
                            .ifEmpty { obj.optString("tv_genre_id") }
                            .trim()

                        var resolvedCategoryName = ""

                        if (catName.isNotEmpty() && !isGenericCategory(catName)) {
                            resolvedCategoryName = catName
                        }

                        if (resolvedCategoryName.isEmpty() && categoryId.isNotEmpty()) {
                            val mappedName = categoriesMap[categoryId]
                            if (mappedName != null && mappedName.isNotEmpty() && !isGenericCategory(mappedName)) {
                                resolvedCategoryName = mappedName
                            }
                        }

                        val itemCatName = obj.optString("category_name")
                            .ifEmpty { obj.optString("genre_name") }
                            .trim()
                        if (resolvedCategoryName.isEmpty() && itemCatName.isNotEmpty() && !isGenericCategory(itemCatName)) {
                            resolvedCategoryName = itemCatName
                        }

                        if (resolvedCategoryName.isEmpty() && categoryId.isNotEmpty()) {
                            val mappedName = categoriesMap[categoryId]
                            if (mappedName != null && mappedName.isNotEmpty()) {
                                resolvedCategoryName = mappedName
                            }
                        }

                        if (resolvedCategoryName.isEmpty() && itemCatName.isNotEmpty()) {
                            resolvedCategoryName = itemCatName
                        }
                        if (resolvedCategoryName.isEmpty() && categoryId.isNotEmpty()) {
                            resolvedCategoryName = categoryId
                        }
                        if (resolvedCategoryName.isEmpty()) {
                            resolvedCategoryName = if (catName.isNotEmpty()) catName else defaultGroupName
                        }

                        var streamUrl = cmd
                        if (type.equals("Series", ignoreCase = true) && id.isNotEmpty()) {
                            streamUrl = "stalker://series/$id?cmd=${java.net.URLEncoder.encode(cmd, "UTF-8")}"
                        }

                        if (name.isNotEmpty() && streamUrl.isNotEmpty()) {
                            pageItems.add(
                                ChannelItem(
                                    playlistId = playlistId,
                                    name = name,
                                    logoUrl = logo,
                                    streamUrl = streamUrl,
                                    groupName = resolvedCategoryName,
                                    type = type
                                )
                            )
                        }
                    } catch (e: Exception) {
                        Log.e("STALKER_DEBUG", "Error parsing item at index $i on page $page: ${e.message}")
                    }
                }
                pageItems
            }
        } catch (e: Exception) {
            Log.e("STALKER_DEBUG", "Network or processing error on page $page: ${e.message}")
            emptyList()
        }
    }

    private suspend fun fetchStalkerItemsPaginated(
        client: okhttp3.OkHttpClient,
        cleanUrl: String,
        token: String,
        macAddress: String,
        playlistId: Long,
        actionType: String, // "vod" or "series"
        type: String, // "Movie" or "Series"
        catId: String?, // Category ID if filtering
        catName: String,
        defaultGroupName: String,
        categoriesMap: Map<String, String> = emptyMap(),
        maxPagesToFetch: Int = 10000,
        endpointPath: String = "server/load.php"
    ): List<ChannelItem> = coroutineScope {
        val pathInfo = resolveStalkerPath(cleanUrl, macAddress, endpointPath)
        val baseUrl = pathInfo.baseUrl
        val activeEndpoint = pathInfo.endpointFile
        val items = mutableListOf<ChannelItem>()
        val categoryQuery = if (catId != null) {
            "&category=$catId&category_id=$catId&genre=$catId"
        } else {
            ""
        }
        
        // Fetch Page 1 first to determine total items and calculate total pages
        val url = "${baseUrl}${activeEndpoint}?type=$actionType&action=get_ordered_list$categoryQuery&p=1&page=1&token=$token&JsHttpRequest=1-xml"
        val requestBuilder = Request.Builder().url(url)
        addStalkerHeaders(requestBuilder, macAddress, baseUrl, token)
        val request = requestBuilder.build()

        Log.d("STALKER_API_LOG", "[STALKER API CALL] GET ordered list (Page 1 info): $url")
        
        var totalPages = 1
        var totalItems = 0
        var maxPageItems = 0

        try {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                Log.d("STALKER_API_LOG", "[STALKER API RESPONSE] GET ordered list (Page 1): $url, Code: ${response.code}")

                if (response.isSuccessful) {
                    val cleaned = cleanStalkerJson(body)
                    if (cleaned.isNotEmpty()) {
                        val json = JSONObject(cleaned)
                        val jsObj = json.optJSONObject("js") ?: json.optJSONObject("result") ?: json
                        totalItems = json.optInt("total_items", jsObj.optInt("total_items", 0))
                        maxPageItems = json.optInt("max_page_items", jsObj.optInt("max_page_items", 0))
                    }

                    // Extract and parse page 1 items
                    val jsArray = cleanAndExtractStalkerArray(body)
                    if (jsArray != null && jsArray.length() > 0) {
                        val firstPageItems = mutableListOf<ChannelItem>()
                        val effectiveMaxPageItems = if (maxPageItems > 0) maxPageItems else jsArray.length()

                        for (i in 0 until jsArray.length()) {
                            try {
                                val obj = jsArray.optJSONObject(i) ?: continue
                                val id = obj.optString("id")
                                    .ifEmpty { obj.optString("series_id") }
                                    .ifEmpty { obj.optString("movie_id") }
                                    .ifEmpty { obj.optString("item_id") }
                                    .ifEmpty { obj.hashCode().toString() }
                                    .trim()
                                val name = obj.optString("name")
                                    .ifEmpty { obj.optString("series_name") }
                                    .ifEmpty { obj.optString("movie_name") }
                                    .ifEmpty { obj.optString("title") }
                                    .ifEmpty { obj.optString("o_name") }
                                    .ifEmpty { obj.optString("original_name") }
                                    .ifEmpty { obj.optString("label") }
                                    .trim()
                                val cmd = obj.optString("cmd")
                                    .ifEmpty { obj.optString("path") }
                                    .ifEmpty { obj.optString("url") }
                                    .trim()
                                val logo = obj.optString("logo")
                                    .ifEmpty { obj.optString("screenshot") }
                                    .ifEmpty { obj.optString("poster") }
                                    .trim()

                                val categoryId = obj.optString("category_id")
                                    .ifEmpty { obj.optString("genre_id") }
                                    .ifEmpty { obj.optString("tv_genre_id") }
                                    .trim()

                                var resolvedCategoryName = ""
                                if (catName.isNotEmpty() && !isGenericCategory(catName)) {
                                    resolvedCategoryName = catName
                                }
                                if (resolvedCategoryName.isEmpty() && categoryId.isNotEmpty()) {
                                    val mappedName = categoriesMap[categoryId]
                                    if (mappedName != null && mappedName.isNotEmpty() && !isGenericCategory(mappedName)) {
                                        resolvedCategoryName = mappedName
                                    }
                                }
                                val itemCatName = obj.optString("category_name")
                                    .ifEmpty { obj.optString("genre_name") }
                                    .trim()
                                if (resolvedCategoryName.isEmpty() && itemCatName.isNotEmpty() && !isGenericCategory(itemCatName)) {
                                    resolvedCategoryName = itemCatName
                                }
                                if (resolvedCategoryName.isEmpty() && categoryId.isNotEmpty()) {
                                    val mappedName = categoriesMap[categoryId]
                                    if (mappedName != null && mappedName.isNotEmpty()) {
                                        resolvedCategoryName = mappedName
                                    }
                                }
                                if (resolvedCategoryName.isEmpty() && itemCatName.isNotEmpty()) {
                                    resolvedCategoryName = itemCatName
                                }
                                if (resolvedCategoryName.isEmpty() && categoryId.isNotEmpty()) {
                                    resolvedCategoryName = categoryId
                                }
                                if (resolvedCategoryName.isEmpty()) {
                                    resolvedCategoryName = if (catName.isNotEmpty()) catName else defaultGroupName
                                }

                                var streamUrl = cmd
                                if (type.equals("Series", ignoreCase = true) && id.isNotEmpty()) {
                                    streamUrl = "stalker://series/$id?cmd=${java.net.URLEncoder.encode(cmd, "UTF-8")}"
                                }

                                if (name.isNotEmpty() && streamUrl.isNotEmpty()) {
                                    firstPageItems.add(
                                        ChannelItem(
                                            playlistId = playlistId,
                                            name = name,
                                            logoUrl = logo,
                                            streamUrl = streamUrl,
                                            groupName = resolvedCategoryName,
                                            type = type
                                        )
                                    )
                                }
                            } catch (e: Exception) {
                                Log.e("STALKER_DEBUG", "Error parsing page 1 item at index $i: ${e.message}")
                            }
                        }
                        items.addAll(firstPageItems)

                        // Calculate total pages dynamically
                        if (totalItems > 0) {
                            totalPages = ((totalItems + effectiveMaxPageItems - 1) / effectiveMaxPageItems).coerceAtMost(maxPagesToFetch)
                        } else if (jsArray.length() >= effectiveMaxPageItems) {
                            // Tentatively fetch up to max pages if we suspect more pages exist but total_items is missing
                            totalPages = maxPagesToFetch
                        }
                        Log.d("STALKER_DEBUG", "[STALKER PAGINATION INFO] catId=$catId, totalItems=$totalItems, maxPageItems=$effectiveMaxPageItems -> totalPages=$totalPages (Requested Limit: $maxPagesToFetch)")
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("STALKER_DEBUG", "Error fetching first page of VOD/Series list: ${e.message}")
            return@coroutineScope emptyList()
        }

        // Fetch remaining pages in parallel chunks of 8 to accelerate downloading drastically!
        if (totalPages > 1) {
            val pagesToFetch = (2..totalPages).toList()
            val chunks = pagesToFetch.chunked(8)
            for (chunk in chunks) {
                val deferreds = chunk.map { pageNum ->
                    async(Dispatchers.IO) {
                        fetchSingleStalkerPage(
                            client = client,
                            cleanUrl = cleanUrl,
                            token = token,
                            macAddress = macAddress,
                            playlistId = playlistId,
                            actionType = actionType,
                            type = type,
                            catId = catId,
                            catName = catName,
                            defaultGroupName = defaultGroupName,
                            categoriesMap = categoriesMap,
                            page = pageNum,
                            endpointPath = activeEndpoint
                        )
                    }
                }
                val chunkResults = deferreds.awaitAll()
                var emptyPageFound = false
                for (res in chunkResults) {
                    if (res.isEmpty()) {
                        emptyPageFound = true
                    }
                    items.addAll(res)
                }
                // If any concurrent page was empty, we assume we have reached the end of the lists (safety break)
                if (emptyPageFound && totalItems <= 0) {
                    Log.d("STALKER_DEBUG", "Empty page returned during chunked pagination. Breaking.")
                    break
                }
            }
        }

        items
    }

    private suspend fun fetchAllStalkerPages(
        client: okhttp3.OkHttpClient,
        cleanUrl: String,
        token: String,
        macAddress: String,
        playlistId: Long,
        actionType: String,
        type: String,
        catId: String?,
        catName: String,
        endpointPath: String = "server/load.php"
    ): List<ChannelItem> = withContext(Dispatchers.IO) {
        val pathInfo = resolveStalkerPath(cleanUrl, macAddress, endpointPath)
        val baseUrl = pathInfo.baseUrl
        val activeEndpoint = pathInfo.endpointFile
        val allItems = mutableListOf<ChannelItem>()
        var currentPage = 1
        var maxPage = 1
        
        do {
            val categoryQuery = catId?.let { "&category=$it" } ?: ""
            val url = "${baseUrl}${activeEndpoint}?type=$actionType&action=get_ordered_list$categoryQuery&p=$currentPage&token=$token&JsHttpRequest=1-xml"
            
            val request = Request.Builder().url(url).apply { 
                addStalkerHeaders(this, macAddress, baseUrl, token) 
            }.build()

            try {
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext allItems
                    val body = response.body?.string().orEmpty()
                    val cleaned = cleanStalkerJson(body)
                    val json = try { JSONObject(cleaned) } catch (e: Exception) { null } ?: return@withContext allItems
                    
                    val jsObj = json.optJSONObject("js") ?: json.optJSONObject("result") ?: json
                    maxPage = json.optInt("max_page_no", jsObj.optInt("max_page_no", currentPage))
                    
                    val dataArray = jsObj.optJSONArray("data") ?: jsObj.optJSONArray("results") ?: cleanAndExtractStalkerArray(body)
                    if (dataArray == null || dataArray.length() == 0) return@withContext allItems
                    
                    for (i in 0 until dataArray.length()) {
                        val obj = dataArray.optJSONObject(i) ?: continue
                        val id = obj.optString("id")
                            .ifEmpty { obj.optString("series_id") }
                            .ifEmpty { obj.optString("movie_id") }
                            .ifEmpty { obj.optString("item_id") }
                            .trim()
                        val name = obj.optString("name")
                            .ifEmpty { obj.optString("series_name") }
                            .ifEmpty { obj.optString("movie_name") }
                            .ifEmpty { obj.optString("title") }
                            .trim()
                        val cmd = obj.optString("cmd")
                            .ifEmpty { obj.optString("path") }
                            .ifEmpty { obj.optString("url") }
                            .trim()
                        val logo = obj.optString("logo")
                            .ifEmpty { obj.optString("screenshot_uri") }
                            .ifEmpty { obj.optString("screenshot") }
                            .ifEmpty { obj.optString("poster") }
                            .trim()
                        
                        if (name.isEmpty()) continue
                        val cmdForUrl = if (cmd.isEmpty()) id else cmd
                        
                        if (type.equals("Series", ignoreCase = true)) {
                            val streamUrl = "stalker://series/$id?cmd=${java.net.URLEncoder.encode(cmdForUrl, "UTF-8")}"
                            allItems.add(
                                ChannelItem(
                                    playlistId = playlistId,
                                    name = name,
                                    logoUrl = logo,
                                    streamUrl = streamUrl,
                                    groupName = catName,
                                    type = type
                                )
                            )
                        } else {
                            val streamUrl = if (cmd.startsWith("http://") || cmd.startsWith("https://")) {
                                cmd
                            } else {
                                "stalker://vod/$id?cmd=${java.net.URLEncoder.encode(cmdForUrl, "UTF-8")}"
                            }
                            allItems.add(
                                ChannelItem(
                                    playlistId = playlistId,
                                    name = name,
                                    logoUrl = logo,
                                    streamUrl = streamUrl,
                                    groupName = catName,
                                    type = type
                                )
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("STALKER_DEBUG", "Error fetching/parsing stalker page $currentPage: ${e.message}")
                break
            }
            currentPage++
        } while (currentPage <= maxPage)
        
        allItems
    }

    private suspend fun resolveStalkerPlayLinkForEpisode(
        client: okhttp3.OkHttpClient,
        cleanUrl: String,
        token: String,
        mac: String,
        cmd: String,
        epNum: String,
        seasonNum: String,
        endpointPath: String = "server/load.php"
    ): String = withContext(Dispatchers.IO) {
        val pathInfo = resolveStalkerPath(cleanUrl, mac, endpointPath)
        val baseUrl = pathInfo.baseUrl
        val activeEndpoint = pathInfo.endpointFile
        Log.d("PlaybackDebug", "resolveStalkerPlayLinkForEpisode: Cached full base URL '$baseUrl', endpoint '$activeEndpoint' for portal '$cleanUrl' (MAC: $mac)")
        Log.d("StalkerRepository", "resolveStalkerPlayLinkForEpisode: Cached full base URL '$baseUrl', endpoint '$activeEndpoint' for portal '$cleanUrl' (MAC: $mac)")
        val encodedCmd = java.net.URLEncoder.encode(cmd, "UTF-8")
        
        // We will try several combinations of type and action parameter structures
        val queryParamsToTry = mutableListOf<String>()
        
        // 1. type=vod combinations
        queryParamsToTry.add("type=vod&action=create_link&cmd=$encodedCmd&series=$epNum&season=$seasonNum&token=$token")
        queryParamsToTry.add("type=vod&action=create_link&cmd=$encodedCmd&series=$epNum&token=$token")
        queryParamsToTry.add("type=vod&action=create_link&cmd=$encodedCmd&token=$token")
        
        // Standard non-JsHttpRequest and JsHttpRequest-1-xml variations
        val allQueries = mutableListOf<String>()
        for (qp in queryParamsToTry) {
            allQueries.add("$qp&JsHttpRequest=1-xml")
            allQueries.add(qp)
        }
        
        for (qp in allQueries) {
            val url = "${baseUrl}${activeEndpoint}?$qp"
            Log.d("PlaybackDebug", "StalkerRepository create_link URL: $url")
            Log.d("StalkerRepository", "StalkerRepository create_link URL: $url")
            val request = Request.Builder().url(url).apply {
                addStalkerHeaders(this, mac, baseUrl, token)
            }.build()
            
            try {
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string().orEmpty()
                        val resolved = parseStalkerPlayLink(body)
                        if (resolved != null && resolved.isNotEmpty()) {
                            // Ensure absolute URL if we get a relative path
                            if (!resolved.startsWith("http://") && !resolved.startsWith("https://") && !resolved.startsWith("rtmp://") && !resolved.startsWith("rtsp://")) {
                                if (resolved.startsWith("/")) {
                                    val domain = cleanUrl.substringBefore("/server")
                                    return@withContext "$domain$resolved"
                                }
                            }
                            return@withContext resolved
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w("StalkerRepository", "Failed create_link try: $url, error: ${e.message}")
            }
        }
        
        cmd // Default fallback to raw cmd
    }

    private suspend fun fetchSeriesEpisodes(
        client: okhttp3.OkHttpClient,
        cleanUrl: String,
        token: String,
        mac: String,
        playlistId: Long,
        seriesId: String,
        seriesName: String,
        catName: String,
        endpointPath: String = "server/load.php"
    ): List<ChannelItem> = withContext(Dispatchers.IO) {
        val pathInfo = resolveStalkerPath(cleanUrl, mac, endpointPath)
        val baseUrl = pathInfo.baseUrl
        val activeEndpoint = pathInfo.endpointFile
        // Data class for local episode representation
        data class LocalStalkerEpisode(val name: String, val cmd: String, val seasonNum: String, val epNum: String)
        val extractedEpisodes = mutableListOf<LocalStalkerEpisode>()
        val inlineEpisodes = mutableListOf<LocalStalkerEpisode>()
        
        val seasonIds = mutableListOf<String>()
        val seasonNames = mutableMapOf<String, String>() // Map from seasonId to season name/number

        // 1. get_series_info to get the seasons
        var body = ""
        for (t in listOf("series", "stalker", "vod", "tv_series")) {
            val infoUrl = "${baseUrl}${activeEndpoint}?type=$t&action=get_series_info&series_id=$seriesId&token=$token&JsHttpRequest=1-xml"
            val request = Request.Builder().url(infoUrl).apply {
                addStalkerHeaders(this, mac, baseUrl, token)
            }.build()
            try {
                val response = client.newCall(request).execute()
                try {
                    if (response.isSuccessful) {
                        body = response.body?.string().orEmpty()
                        if (body.contains("seasons") || body.contains("episodes") || body.contains("series")) {
                            break
                        }
                    }
                } finally {
                    response.close()
                }
            } catch (e: Exception) {
                Log.w("StalkerRepository", "Failed get_series_info with type $t: ${e.message}")
            }
        }

        if (body.isNotEmpty()) {
            val cleaned = cleanStalkerJson(body)
            val jsonObj = try { JSONObject(cleaned) } catch (e: Exception) { null }
            val finalDataObj = when {
                jsonObj == null -> null
                jsonObj.has("seasons") || jsonObj.has("series") || jsonObj.has("list") || jsonObj.has("episodes") -> jsonObj
                jsonObj.has("js") -> jsonObj.optJSONObject("js") ?: (try { JSONObject(jsonObj.optString("js")) } catch(e: Exception) { null })
                jsonObj.has("result") -> jsonObj.optJSONObject("result") ?: (try { JSONObject(jsonObj.optString("result")) } catch(e: Exception) { null })
                else -> jsonObj
            }

            if (finalDataObj != null) {
                val seasonsJsonArray = finalDataObj.optJSONArray("seasons")
                val seasonsJsonObject = finalDataObj.optJSONObject("seasons")
                if (seasonsJsonArray != null && seasonsJsonArray.length() > 0) {
                    for (s in 0 until seasonsJsonArray.length()) {
                        val seasonObj = seasonsJsonArray.optJSONObject(s) ?: continue
                        val sId = listOf("id", "season_id", "series_number", "season_number")
                            .map { seasonObj.optString(it).trim() }
                            .firstOrNull { it.isNotEmpty() && it != "null" } ?: "${s + 1}"
                        if (sId.isNotEmpty() && !seasonIds.contains(sId)) {
                            seasonIds.add(sId)
                            val sNum = seasonObj.optString("season_number").ifEmpty { seasonObj.optString("number") }.ifEmpty { "${s + 1}" }.trim()
                            seasonNames[sId] = sNum
                        }
                        
                        // Parse inline episodes as fallback
                        val episodesArray = seasonObj.optJSONArray("episodes") ?: seasonObj.optJSONArray("series") ?: seasonObj.optJSONArray("list")
                        if (episodesArray != null) {
                            for (e in 0 until episodesArray.length()) {
                                val epObj = episodesArray.optJSONObject(e) ?: continue
                                val cmd = listOf("cmd", "path", "url", "movie_cmd").map { epObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: ""
                                val epNum = listOf("episode_number", "episode_num", "series_number", "id").map { epObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: "${e + 1}"
                                val title = listOf("name", "title", "episode_name").map { epObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: "Épisode $epNum"
                                if (cmd.isNotEmpty()) {
                                    inlineEpisodes.add(LocalStalkerEpisode(title, cmd, "${s + 1}", epNum))
                                }
                            }
                        }
                    }
                } else if (seasonsJsonObject != null) {
                    val keys = seasonsJsonObject.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        val seasonObj = seasonsJsonObject.optJSONObject(key) ?: continue
                        val sId = listOf("id", "season_id", "series_number", "season_number")
                            .map { seasonObj.optString(it).trim() }
                            .firstOrNull { it.isNotEmpty() && it != "null" } ?: key
                        if (sId.isNotEmpty() && !seasonIds.contains(sId)) {
                            seasonIds.add(sId)
                            val sNum = seasonObj.optString("season_number").ifEmpty { seasonObj.optString("number") }.ifEmpty { key }.trim()
                            seasonNames[sId] = sNum
                        }
                        
                        // Parse inline episodes as fallback
                        val episodesArray = seasonObj.optJSONArray("episodes") ?: seasonObj.optJSONArray("series") ?: seasonObj.optJSONArray("list")
                        if (episodesArray != null) {
                            for (e in 0 until episodesArray.length()) {
                                val epObj = episodesArray.optJSONObject(e) ?: continue
                                val cmd = listOf("cmd", "path", "url", "movie_cmd").map { epObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: ""
                                val epNum = listOf("episode_number", "episode_num", "series_number", "id").map { epObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: "${e + 1}"
                                val title = listOf("name", "title", "episode_name").map { epObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: "Épisode $epNum"
                                if (cmd.isNotEmpty()) {
                                    inlineEpisodes.add(LocalStalkerEpisode(title, cmd, key, epNum))
                                }
                            }
                        }
                    }
                } else {
                    // Check if episodes are at root of finalDataObj
                    val episodesArray = finalDataObj.optJSONArray("episodes") ?: finalDataObj.optJSONArray("series") ?: finalDataObj.optJSONArray("list")
                    if (episodesArray != null) {
                        for (e in 0 until episodesArray.length()) {
                            val epObj = episodesArray.optJSONObject(e) ?: continue
                            val cmd = listOf("cmd", "path", "url", "movie_cmd").map { epObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: ""
                            val epNum = listOf("episode_number", "episode_num", "series_number", "id").map { epObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: "${e + 1}"
                            val title = listOf("name", "title", "episode_name").map { epObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: "Épisode $epNum"
                            val seasonNum = listOf("season", "season_num", "season_number").map { epObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: "1"
                            if (cmd.isNotEmpty()) {
                                inlineEpisodes.add(LocalStalkerEpisode(title, cmd, seasonNum, epNum))
                            }
                        }
                    }
                }
            }
        }

        // 2. Query episodes for each season using get_ordered_list
        val seasonEpisodes = mutableListOf<LocalStalkerEpisode>()
        if (seasonIds.isNotEmpty()) {
            for (seasonId in seasonIds) {
                val seasonName = seasonNames[seasonId] ?: seasonId
                val episodesUrl = "${baseUrl}${activeEndpoint}?type=vod&action=get_ordered_list&movie_id=$seriesId&season_id=$seasonId&episode_id=0&category=&fav=0&sortby=added&hd=0&not_ended=0&p=1&token=$token&JsHttpRequest=1-xml"
                val epBuilder = Request.Builder().url(episodesUrl)
                addStalkerHeaders(epBuilder, mac, baseUrl, token)
                try {
                    client.newCall(epBuilder.build()).execute().use { epResponse ->
                        if (epResponse.isSuccessful) {
                            val epBody = epResponse.body?.string().orEmpty()
                            val epJsonArr = cleanAndExtractStalkerArray(epBody)
                            if (epJsonArr != null) {
                                for (i in 0 until epJsonArr.length()) {
                                    val obj = epJsonArr.optJSONObject(i) ?: continue
                                    val title = obj.optString("name").ifEmpty { obj.optString("title") }.trim()
                                    val cmd = obj.optString("cmd").ifEmpty { obj.optString("path") }.ifEmpty { obj.optString("url") }.trim()
                                    val seasonNum = obj.optString("series_number").ifEmpty { obj.optString("season_number") }.ifEmpty { seasonName }.trim()
                                    val epNum = obj.optString("episode_number").ifEmpty { obj.optString("episode_num") }.ifEmpty { "${i + 1}" }.trim()
                                    if (title.isNotEmpty() && cmd.isNotEmpty()) {
                                        seasonEpisodes.add(LocalStalkerEpisode(title, cmd, seasonNum, epNum))
                                    }
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e("StalkerRepository", "Failed to fetch episodes for season $seasonId: ${e.message}")
                }
            }
        }

        if (seasonEpisodes.isNotEmpty()) {
            extractedEpisodes.addAll(seasonEpisodes)
        } else {
            extractedEpisodes.addAll(inlineEpisodes)
        }

        // 3. Resolve the actual play link using create_link for each episode
        val resolvedChannels = mutableListOf<ChannelItem>()
        coroutineScope {
            val chunkedEpisodes = extractedEpisodes.chunked(10) // Chunk by 10 to avoid overloading portal
            for (chunk in chunkedEpisodes) {
                val deferreds = chunk.map { ep ->
                    async(Dispatchers.IO) {
                        val realUrl = resolveStalkerPlayLinkForEpisode(
                            client = client,
                            cleanUrl = cleanUrl,
                            token = token,
                            mac = mac,
                            cmd = ep.cmd,
                            epNum = ep.epNum,
                            seasonNum = ep.seasonNum
                        )
                        
                        val seasonNo = ep.seasonNum.toIntOrNull()?.let { String.format("%02d", it) } ?: ep.seasonNum
                        val epNo = ep.epNum.toIntOrNull()?.let { String.format("%02d", it) } ?: ep.epNum
                        val formattedName = "$seriesName - S${seasonNo}E${epNo}: ${ep.name}"

                        ChannelItem(
                            playlistId = playlistId,
                            name = formattedName,
                            logoUrl = "",
                            streamUrl = realUrl,
                            groupName = catName,
                            type = "Series"
                        )
                    }
                }
                resolvedChannels.addAll(deferreds.awaitAll())
            }
        }
        resolvedChannels
    }

    private fun parseStalkerPlayLink(body: String): String? {
        val cleaned = cleanStalkerJson(body)
        val json = try { JSONObject(cleaned) } catch (e: Exception) { null } ?: return null
        var finalUrl = ""
        if (json.has("js")) {
            val jsObj = json.optJSONObject("js")
            if (jsObj != null) {
                finalUrl = jsObj.optString("cmd").ifEmpty { jsObj.optString("url") }
            } else {
                finalUrl = json.optString("js")
            }
        }
        if (finalUrl.isEmpty() && json.has("result")) {
            val resObj = json.optJSONObject("result")
            if (resObj != null) {
                finalUrl = resObj.optString("cmd").ifEmpty { resObj.optString("url") }
            } else {
                finalUrl = json.optString("result")
            }
        }
        if (finalUrl.isEmpty() && json.has("cmd")) {
            finalUrl = json.optString("cmd")
        }

        if (finalUrl.isNotEmpty()) {
            var url = finalUrl.trim()
            if (url.startsWith("ffmpeg ")) url = url.substring(7).trim()
            if (url.startsWith("auto ")) url = url.substring(5).trim()
            if (url.startsWith("standalone ")) url = url.substring(11).trim()
            if (url.startsWith("ffrt ")) url = url.substring(5).trim()
            return url
        }
        return null
    }

    private fun cleanShowName(name: String): String {
        return name
            .replace("(?i)\\b(season|saison|s)\\s*\\d+\\b".toRegex(), "")
            .replace("\\s+".toRegex(), " ")
            .trim()
            .removeSuffix("-")
            .removeSuffix(":")
            .trim()
    }

    private fun isItemSeries(obj: JSONObject, name: String): Boolean {
        if (obj.optInt("is_series", 0) == 1 ||
            obj.optBoolean("is_series", false) ||
            obj.optString("is_series", "").trim() == "1") {
            return true
        }
        val seriesVal = obj.opt("series")
        if (seriesVal != null) {
            if (seriesVal is JSONArray && seriesVal.length() > 0) return true
            if (seriesVal is Number && seriesVal.toInt() > 0) return true
            val seriesStr = seriesVal.toString().trim()
            if (seriesStr.isNotEmpty() && seriesStr != "0" && seriesStr != "[]" && seriesStr != "null") return true
        }
        val cmd = obj.optString("cmd").ifEmpty { obj.optString("path") }.ifEmpty { obj.optString("url") }.trim()
        if (cmd.isEmpty() && (obj.has("seasons") || obj.has("episodes") || obj.has("series_id"))) {
            return true
        }
        val lower = name.lowercase()
        if (lower.contains("(série)") || lower.contains("[série]") || lower.contains("(serie)") || lower.contains("[serie]") ||
            lower.contains("saison ") || lower.contains("season ") ||
            Regex("(?i)\\b(s\\d+|s0\\d+|saison\\s*\\d+|season\\s*\\d+)\\b").containsMatchIn(name)) {
            return true
        }
        return false
    }

    private suspend fun fetchCompleteStalkerItems(
        client: okhttp3.OkHttpClient,
        cleanUrl: String,
        token: String,
        macAddress: String,
        playlistId: Long,
        actionType: String, // "vod" or "series"
        type: String, // "Movie" or "Series"
        defaultGroupName: String,
        endpointPath: String = "server/load.php",
        pagesCounter: java.util.concurrent.atomic.AtomicInteger? = null,
        globalSeenIds: MutableSet<String>? = null,
        onStatusUpdate: (String) -> Unit = {}
    ): List<ChannelItem> = coroutineScope {
        val pathInfo = resolveStalkerPath(cleanUrl, macAddress, endpointPath)
        val baseUrl = pathInfo.baseUrl
        val activeEndpoint = pathInfo.endpointFile
        Log.d("StalkerRepository", "Handshake unique obtenu, token=$token, baseUrl=$baseUrl, lancement des récupérations de contenu")
        Log.d("StalkerRepository", "fetchCompleteStalkerItems ($type): Cached full base URL '$baseUrl', endpoint '$activeEndpoint' for portal '$cleanUrl' (MAC: $macAddress)")
        Log.d("STALKER_DEBUG", "fetchCompleteStalkerItems ($type): Cached full base URL '$baseUrl', endpoint '$activeEndpoint' for portal '$cleanUrl'")

        val rawCategoriesMap = fetchStalkerCategories(client, baseUrl, token, macAddress, actionType, endpointPath = activeEndpoint)

        // 1. DÉTECTE, EXCLUS LA CATÉGORIE "ALL"/"*" ET TRIE DÉTERMINISTEMENT PAR ID
        val sortedCategories = rawCategoriesMap.filter { (id, title) ->
            val cleanId = id.trim()
            val lowerTitle = title.trim().lowercase()
            cleanId != "*" && cleanId.lowercase() != "all" &&
                lowerTitle != "all" && lowerTitle != "tout" && lowerTitle != "tous"
        }.toList().sortedWith(Comparator { (id1, _), (id2, _) ->
            val int1 = id1.trim().toIntOrNull()
            val int2 = id2.trim().toIntOrNull()
            when {
                int1 != null && int2 != null -> int1.compareTo(int2)
                int1 != null && int2 == null -> -1
                int1 == null && int2 != null -> 1
                else -> id1.trim().compareTo(id2.trim(), ignoreCase = true)
            }
        })

        val categoriesToIterate: List<Pair<String, String>> = if (sortedCategories.isNotEmpty()) {
            sortedCategories
        } else if (rawCategoriesMap.isNotEmpty()) {
            rawCategoriesMap.toList()
        } else {
            // Fallback : si aucune catégorie spécifique n'est trouvée (ou seulement All/*), on effectue une pagination sans paramètre de catégorie
            listOf(Pair("", defaultGroupName))
        }

        Log.d("StalkerRepository", "Fetching $type items. Categories to traverse: ${categoriesToIterate.size} (sorted deterministically by ID)")

        // 2. LIMITE LA CONCURRENCE À MAXIMUM 8 CATÉGORIES SIMULTANÉES POUR HAUTE VITESSE
        val semaphore = kotlinx.coroutines.sync.Semaphore(8)
        val allRetrievedItems = mutableListOf<ChannelItem>()
        val failedCategories = java.util.concurrent.CopyOnWriteArrayList<String>()
        var sumAnnouncedTotalItems = 0
        val isSeries = type.equals("Series", ignoreCase = true)
        val totalCats = categoriesToIterate.size

        val deferredResults = categoriesToIterate.mapIndexed { index, (catId, catName) ->
            async(Dispatchers.IO) {
                semaphore.withPermit {
                    val indexStr = "${index + 1}/$totalCats"
                    
                    // 4. LOG DE PROGRESSION ORDONNÉ (début)
                    Log.d("StalkerRepository", "Catégorie $indexStr: '$catName' - début")
                    onStatusUpdate("Téléchargement $type - $catName ($indexStr)...")

                    val catItems = mutableListOf<ChannelItem>()
                    var totalItems = 0
                    var pagesTraversedForCat = 0
                    val seenIdsInCat = mutableSetOf<String>()
                    var currentPage = 1
                    var itemsRetrievedForCategory = 0
                    var consecutiveEmptyOrDuplicatePages = 0
                    var consecutiveFailedPages = 0
                    var activeCatParam = if (catId.isEmpty() || catId == "*") "" else "&category=$catId&category_id=$catId"
                    var activeActionType = actionType
                    var fallbackStage = 0

                    val pageClient = client.newBuilder()
                        .callTimeout(10, TimeUnit.SECONDS)
                        .readTimeout(10, TimeUnit.SECONDS)
                        .connectTimeout(10, TimeUnit.SECONDS)
                        .build()

                    while (true) {
                        val totalPages = if (totalItems > 0) ((totalItems + 13) / 14) else 0
                        val maxPagesAllowed = if (totalPages > 0) totalPages else 300
                        if (currentPage > maxPagesAllowed) {
                            Log.d("StalkerRepository", "Fin de pagination atteinte pour '$catName' (page $currentPage > $maxPagesAllowed pages)")
                            break
                        }

                        val progressPageStr = if (totalPages > 0) "$currentPage/$totalPages" else "$currentPage"
                        val progressTypeLabel = if (isSeries) "séries" else "films"
                        onStatusUpdate("Catégorie $indexStr : page $progressPageStr - ${catItems.size} $progressTypeLabel trouvés")

                        val catParam = activeCatParam
                        val url = "${baseUrl}${activeEndpoint}?type=$activeActionType&action=get_ordered_list$catParam&p=$currentPage&page=$currentPage&token=$token&JsHttpRequest=1-xml"

                        var responseBody = ""
                        var isSuccess = false
                        var httpCode = 0
                        var pageAttempt = 1
                        var lastPageError = ""
                        var pageSuccess = false

                        while (pageAttempt <= 3 && !pageSuccess) {
                            if (pageAttempt > 1) {
                                delay(2000)
                            }
                            try {
                                val requestBuilder = Request.Builder().url(url)
                                addStalkerHeaders(requestBuilder, macAddress, baseUrl, token)
                                val request = requestBuilder.build()

                                pageClient.newCall(request).execute().use { response ->
                                    httpCode = response.code
                                    isSuccess = response.isSuccessful
                                    if (isSuccess) {
                                        responseBody = response.body?.string() ?: ""
                                    }
                                }
                                if (!isSuccess) {
                                    lastPageError = "Erreur HTTP $httpCode"
                                    Log.w("StalkerRepository", "Échec page $currentPage (Catégorie '$catName', tentative $pageAttempt/3) : $lastPageError")
                                } else {
                                    pageSuccess = true
                                }
                            } catch (e: Exception) {
                                lastPageError = e.message ?: e.javaClass.simpleName
                                Log.w("StalkerRepository", "Échec page $currentPage (Catégorie '$catName', tentative $pageAttempt/3) : $lastPageError")
                            }
                            if (!pageSuccess) {
                                pageAttempt++
                            }
                        }

                        if (!pageSuccess) {
                            consecutiveFailedPages++
                            Log.w("StalkerRepository", "[WARNING] Abandon de la page $currentPage (Catégorie '$catName') après 3 tentatives. Échec consécutif : $consecutiveFailedPages")
                            failedCategories.add("$catName (page $currentPage échouée: $lastPageError)")
                            if (consecutiveFailedPages >= 2) {
                                Log.w("StalkerRepository", "[WARNING] Arrêt de la catégorie '$catName' après $consecutiveFailedPages pages échouées consécutives.")
                                break
                            }
                            currentPage++
                            continue
                        } else {
                            consecutiveFailedPages = 0
                        }

                        val cleaned = cleanStalkerJson(responseBody)
                        if (cleaned.isEmpty()) {
                            if (currentPage == 1 && catId.isNotEmpty() && catId != "*") {
                                if (fallbackStage == 0) {
                                    fallbackStage = 1
                                    activeCatParam = "&genre=$catId&genre_id=$catId"
                                    Log.d("StalkerRepository", "Fallback paramètre (JSON vide) vers genre=$catId pour '$catName'")
                                    continue
                                } else if (fallbackStage == 1) {
                                    fallbackStage = 2
                                    activeCatParam = "&category=$catId&category_id=$catId&genre=$catId&genre_id=$catId"
                                    Log.d("StalkerRepository", "Fallback paramètre (JSON vide) vers category+genre=$catId pour '$catName'")
                                    continue
                                } else if (fallbackStage == 2 && isSeries && activeActionType == "series") {
                                    fallbackStage = 3
                                    activeActionType = "vod"
                                    activeCatParam = "&category=$catId&category_id=$catId"
                                    Log.d("StalkerRepository", "Fallback actionType (JSON vide) vers type=vod pour '$catName'")
                                    continue
                                } else if (fallbackStage == 3 && isSeries && activeActionType == "vod") {
                                    fallbackStage = 4
                                    activeActionType = "tv_series"
                                    activeCatParam = "&category=$catId&category_id=$catId"
                                    Log.d("StalkerRepository", "Fallback actionType (JSON vide) vers type=tv_series pour '$catName'")
                                    continue
                                }
                            }
                            if (currentPage == 1) {
                                Log.w("StalkerRepository", "Réponse JSON vide à la page 1 pour '$catName'")
                            }
                            break
                        }

                        val json = try {
                            JSONObject(cleaned)
                        } catch (e: Exception) {
                            consecutiveFailedPages++
                            Log.w("StalkerRepository", "JSON malformé à la page $currentPage pour '$catName': ${e.message}")
                            if (consecutiveFailedPages >= 2) {
                                break
                            }
                            currentPage++
                            continue
                        }
                        val jsObj = json.optJSONObject("js") ?: json.optJSONObject("result") ?: json

                        if (currentPage == 1) {
                            totalItems = json.optInt("total_items", jsObj.optInt("total_items", 0))
                            Log.d("StalkerRepository", "[$actionType] Catégorie '$catName' (ID: '$catId') : total_items annoncé par le serveur = $totalItems")
                            if (totalItems == 0 && (jsObj.optJSONArray("data") == null || jsObj.optJSONArray("data")?.length() == 0)) {
                                Log.w("StalkerRepository", "Total items annoncé à 0 pour '$catName'")
                                break
                            }
                        }

                        val jsArray = cleanAndExtractStalkerArray(responseBody)
                        if (jsArray == null || jsArray.length() == 0) {
                            if (currentPage == 1 && catId.isNotEmpty() && catId != "*") {
                                if (fallbackStage == 0) {
                                    fallbackStage = 1
                                    activeCatParam = "&genre=$catId&genre_id=$catId"
                                    Log.d("StalkerRepository", "Fallback paramètre (0 items) vers genre=$catId pour '$catName'")
                                    continue
                                } else if (fallbackStage == 1) {
                                    fallbackStage = 2
                                    activeCatParam = "&category=$catId&category_id=$catId&genre=$catId&genre_id=$catId"
                                    Log.d("StalkerRepository", "Fallback paramètre (0 items) vers category+genre=$catId pour '$catName'")
                                    continue
                                } else if (fallbackStage == 2 && isSeries && activeActionType == "series") {
                                    fallbackStage = 3
                                    activeActionType = "vod"
                                    activeCatParam = "&category=$catId&category_id=$catId"
                                    Log.d("StalkerRepository", "Fallback actionType (0 items) vers type=vod pour '$catName'")
                                    continue
                                } else if (fallbackStage == 3 && isSeries && activeActionType == "vod") {
                                    fallbackStage = 4
                                    activeActionType = "tv_series"
                                    activeCatParam = "&category=$catId&category_id=$catId"
                                    Log.d("StalkerRepository", "Fallback actionType (0 items) vers type=tv_series pour '$catName'")
                                    continue
                                }
                            }
                            if (currentPage > 1 && (itemsRetrievedForCategory < totalItems || totalItems == 0)) {
                                Log.w("StalkerRepository", "[WARNING] Fin de liste prématurée pour '$catName' à la page $currentPage ($itemsRetrievedForCategory / $totalItems récupérés).")
                            }
                            break
                        }

                        pagesTraversedForCat++
                        pagesCounter?.incrementAndGet()

                        var newUniqueAddedInPage = 0
                        for (i in 0 until jsArray.length()) {
                            val obj = jsArray.optJSONObject(i) ?: continue
                            val id = obj.optString("id")
                                .ifEmpty { obj.optString("series_id") }
                                .ifEmpty { obj.optString("movie_id") }
                                .ifEmpty { obj.optString("item_id") }
                                .ifEmpty { obj.hashCode().toString() }
                                .trim()
                            val name = obj.optString("name")
                                .ifEmpty { obj.optString("series_name") }
                                .ifEmpty { obj.optString("movie_name") }
                                .ifEmpty { obj.optString("title") }
                                .ifEmpty { obj.optString("o_name") }
                                .ifEmpty { obj.optString("original_name") }
                                .ifEmpty { obj.optString("label") }
                                .trim()
                            val cmd = obj.optString("cmd")
                                .ifEmpty { obj.optString("path") }
                                .ifEmpty { obj.optString("url") }
                                .trim()
                            val logo = obj.optString("logo")
                                .ifEmpty { obj.optString("screenshot_uri") }
                                .ifEmpty { obj.optString("screenshot") }
                                .ifEmpty { obj.optString("poster") }
                                .trim()

                            if (name.isEmpty()) continue
                            if (!seenIdsInCat.add(id)) continue
                            val isNewGlobally = globalSeenIds?.add(id) ?: true
                            if (!isNewGlobally) continue

                            val detectedAsSeries = isSeries || isItemSeries(obj, name)
                            val cmdForUrl = if (cmd.isEmpty()) id else cmd
                            if (detectedAsSeries) {
                                val showId = id.substringBefore(":")
                                if (catItems.none { it.streamUrl.startsWith("stalker://series/$showId?") }) {
                                    val streamUrl = "stalker://series/$showId?cmd=${java.net.URLEncoder.encode(cmdForUrl, "UTF-8")}"
                                    catItems.add(
                                        ChannelItem(
                                            playlistId = playlistId,
                                            name = name,
                                            logoUrl = logo,
                                            streamUrl = streamUrl,
                                            groupName = catName,
                                            type = "Series"
                                        )
                                    )
                                }
                            } else {
                                val streamUrl = if (cmd.startsWith("http://") || cmd.startsWith("https://")) {
                                    cmd
                                } else {
                                    "stalker://vod/$id?cmd=${java.net.URLEncoder.encode(cmdForUrl, "UTF-8")}"
                                }
                                catItems.add(
                                    ChannelItem(
                                        playlistId = playlistId,
                                        name = name,
                                        logoUrl = logo,
                                        streamUrl = streamUrl,
                                        groupName = catName,
                                        type = "Movie"
                                    )
                                )
                            }
                            newUniqueAddedInPage++
                        }

                        itemsRetrievedForCategory += jsArray.length()

                        // Protection contre les boucles et détection de catalogue identique (déjà téléchargé dans d'autres catégories/VOD)
                        if (newUniqueAddedInPage == 0) {
                            consecutiveEmptyOrDuplicatePages++
                            if (currentPage == 1 && globalSeenIds != null && globalSeenIds.isNotEmpty()) {
                                Log.w("StalkerRepository", "[WARNING] Catégorie '$catName' retourne un catalogue identique/déjà téléchargé. Arrêt immédiat.")
                                break
                            }
                            if (consecutiveEmptyOrDuplicatePages >= 2) {
                                if (itemsRetrievedForCategory < totalItems || totalItems == 0) {
                                    Log.w("StalkerRepository", "[WARNING] Arrêt pour '$catName' à la page $currentPage : 2 pages consécutives sans nouvel item unique.")
                                }
                                break
                            }
                        } else {
                            consecutiveEmptyOrDuplicatePages = 0
                        }

                        currentPage++
                    }

                    val uniqueAddedInCat = catItems.distinctBy { it.streamUrl }.size
                    // 4. LOG DE PROGRESSION ORDONNÉ (terminé)
                    Log.d("StalkerRepository", "Catégorie $indexStr: '$catName' - terminé, $uniqueAddedInCat items")
                    Log.d("StalkerRepository", "[$actionType] Fin catégorie '$catName' (ID: '$catId') | total_items annoncé : $totalItems | pages réellement parcourues : $pagesTraversedForCat | items uniques ajoutés : $uniqueAddedInCat")

                    Pair(totalItems, catItems)
                }
            }
        }

        val results = deferredResults.awaitAll()
        for ((catTotal, itemsList) in results) {
            sumAnnouncedTotalItems += catTotal
            allRetrievedItems.addAll(itemsList)
        }

        val uniqueItems = allRetrievedItems.distinctBy { it.streamUrl }
        val totalUniqueStored = uniqueItems.size

        // 3. LOG DÉTAILLÉ : Récapitulatif global en fin de synchro complète
        Log.d("StalkerRepository", "=== SYNCHRO COMPLÈTE [$actionType / $type] ===")
        Log.d("StalkerRepository", "Somme de tous les total_items annoncés par catégorie : $sumAnnouncedTotalItems")
        Log.d("StalkerRepository", "Nombre total d'items uniques réellement stockés : $totalUniqueStored")
        if (totalUniqueStored < sumAnnouncedTotalItems) {
            val ecart = sumAnnouncedTotalItems - totalUniqueStored
            Log.w("StalkerRepository", "[WARNING] Écart de comptage pour le catalogue $type : $ecart items de moins que le total annoncé ($totalUniqueStored stockés vs $sumAnnouncedTotalItems annoncés).")
        }
        if (failedCategories.isNotEmpty()) {
            val summaryMsg = "${failedCategories.size} catégorie(s) n'ont pas pu être synchronisées : ${failedCategories.joinToString(", ")}"
            Log.w("StalkerRepository", "[WARNING] $summaryMsg")
            onStatusUpdate("ATTENTION : $summaryMsg")
            delay(3000)
        }
        Log.d("StalkerRepository", "================================================")

        if (uniqueItems.isEmpty()) {
            Log.w("StalkerRepository", "Le portail n'a retourné aucun contenu de type $type.")
            emptyList()
        } else {
            uniqueItems
        }
    }


    private suspend fun <T> withStalkerWakeLock(block: suspend () -> T): T {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
        val wakeLock = try {
            powerManager?.newWakeLock(
                android.os.PowerManager.PARTIAL_WAKE_LOCK,
                "StalkerApp:SyncWakeLock"
            )
        } catch (t: Throwable) {
            Log.w("StalkerRepository", "Could not create WakeLock: ${t.message}")
            null
        }
        return try {
            try {
                wakeLock?.acquire(3 * 60 * 60 * 1000L)
                Log.d("StalkerRepository", "WakeLock acquis pour la synchronisation Stalker")
            } catch (t: Throwable) {
                Log.w("StalkerRepository", "Could not acquire WakeLock: ${t.message}")
            }
            block()
        } finally {
            try {
                if (wakeLock?.isHeld == true) {
                    wakeLock.release()
                    Log.d("StalkerRepository", "WakeLock relâché")
                }
            } catch (t: Throwable) {
                Log.w("StalkerRepository", "Erreur lors du relâchement du WakeLock : ${t.message}")
            }
        }
    }

    suspend fun importStalkerPortal(
        playlistName: String,
        portalUrl: String,
        macAddress: String,
        hideDns: Boolean,
        ipAddress: String? = null,
        loadLive: Boolean = true,
        loadMovies: Boolean = true,
        loadSeries: Boolean = true,
        onStatusUpdate: (String) -> Unit
    ): Long = withContext(Dispatchers.IO) {
      withStalkerWakeLock {
        ApiService.resetHandshakeCounter()
        val macList = macAddress.split(Regex("[,;\\s\\n\\r]+"))
            .map { it.replace("\"", "").replace("'", "").trim() }
            .filter { it.isNotEmpty() }
            .map { formatMacAddress(it).uppercase() }
        
        if (macList.isEmpty()) {
            throw Exception("Veuillez saisir au moins une adresse MAC valide.")
        }

        var formattedMac = macList.first()
        var token = ""
        var resolvedUrl = portalUrl
        var foundWorking = false

        onStatusUpdate("Vérification des adresses MAC (${macList.size})...")

        for ((index, rawMac) in macList.withIndex()) {
            val formatted = formatMacAddress(rawMac)
            onStatusUpdate("Vérification de la MAC (${index + 1}/${macList.size}) : $formatted...")
            try {
                val t = apiService.authenticateStalker(formatted, portalUrl, ipAddress)
                if (t.isNotEmpty()) {
                    formattedMac = formatted
                    token = t
                    val cacheKey = "$portalUrl|$formatted"
                    resolvedUrl = apiService.getHandshakeCache()[cacheKey]?.resolvedUrl ?: portalUrl
                    foundWorking = true
                    Log.d("StalkerRepository", "Successful handshake and authentication with MAC: $formatted")
                    break
                }
            } catch (e: Exception) {
                Log.e("StalkerRepository", "Error testing MAC $formatted: ${e.message}")
                val msg = e.message ?: ""
                if (msg.contains("bloquée") || msg.contains("bloqué") || msg.contains("blocked") || msg.contains("Wrong MAC") || msg.contains("refusée")) {
                    onStatusUpdate("Erreur critique : ${e.message}")
                    throw e
                }
            }
        }

        if (!foundWorking) {
            // Try fallback to the first MAC
            formattedMac = formatMacAddress(macList.first())
            onStatusUpdate("Aucune MAC n'a réussi le handshake. Connexion avec la première MAC...")
            try {
                val t = apiService.authenticateStalker(formattedMac, portalUrl, ipAddress)
                token = t
                val cacheKey = "$portalUrl|$formattedMac"
                resolvedUrl = apiService.getHandshakeCache()[cacheKey]?.resolvedUrl ?: portalUrl
            } catch (e: Exception) {
                Log.e("StalkerRepository", "Fallback authentication error: ${e.message}")
                throw Exception("Échec de la connexion : ${e.message ?: "Le portail est injoignable ou l'adresse MAC est refusée."}")
            }
        }

        onStatusUpdate("MAC active sélectionnée : $formattedMac")
        
        val pathInfo = resolveStalkerPath(portalUrl, formattedMac)
        resolvedUrl = pathInfo.baseUrl
        val endpointPath = pathInfo.endpointFile
        val endpointsToTry = listOf(endpointPath, "server/load.php", "portal.php", "load.php", "c/server/load.php", "c/portal.php", "c/load.php").distinct()

        // Insert or update playlist
        val existingPlaylists = try {
            db.playlistDao().getAllPlaylistsSync().map { it.name }
        } catch (e: Exception) {
            emptyList<String>()
        }
        val finalPlaylistName = if (playlistName.isBlank()) {
            extractStalkerPlaylistNameFromUrl(portalUrl, existingPlaylists)
        } else {
            playlistName.trim()
        }

        val playlistId = db.playlistDao().insertPlaylist(
            PlaylistItem(
                name = finalPlaylistName,
                type = "Stalker",
                url = resolvedUrl,
                macAddress = formattedMac,
                ipAddress = ipAddress,
                customIp = ipAddress,
                isActive = true
            )
        )
        
        val totalHandshakes = ApiService.getHandshakeCount()
        Log.d("StalkerRepository", "Nombre TOTAL de tentatives de handshake effectuées pour cette synchronisation : $totalHandshakes")
        Log.d("StalkerRepository", "Handshake unique obtenu, token=$token, baseUrl=$resolvedUrl, lancement des récupérations de contenu")
        Log.d("StalkerRepository", "Temporisation de 300ms avant le premier appel de contenu (get_categories)...")
        kotlinx.coroutines.delay(300)

        val channels = mutableListOf<ChannelItem>()
        val pagesCounter = java.util.concurrent.atomic.AtomicInteger(0)
        val cleanUrl = resolvedUrl
        val syncSession = StalkerSyncSession(token, resolvedUrl, formattedMac, ipAddress, apiService)
        val client = getUnsafeOkHttpClientWithoutInterceptor().newBuilder()
            .addInterceptor(StalkerSyncSessionInterceptor(syncSession))
            .build()

        // Fetch genres/categories & live channels if loadLive is checked
        if (loadLive) {
            onStatusUpdate("Récupération des catégories...")
            val genreMap = fetchStalkerGenres(client, cleanUrl, token, formattedMac, endpointPath)

            onStatusUpdate("Téléchargement des chaînes Live...")
            val liveActionsToTry = listOf("get_all_channels", "get_itv_channels", "get_ordered_list&genre=*", "get_ordered_list&genre=0", "get_ordered_list", "get_all_channels&force_ch_link_check=0")
            for (ep in endpointsToTry) {
                if (channels.isNotEmpty()) break
                for (action in liveActionsToTry) {
                    if (channels.isNotEmpty()) break
                    try {
                        val channelsUrl = "${cleanUrl}${ep}?type=itv&action=$action&token=$token&JsHttpRequest=1-xml"
                        val requestBuilder = Request.Builder().url(channelsUrl)
                        addStalkerHeaders(requestBuilder, formattedMac, cleanUrl, token)
                        val request = requestBuilder.build()
                            
                        pagesCounter.incrementAndGet()
                        client.newCall(request).execute().use { response ->
                            if (response.isSuccessful) {
                                val body = response.body?.string() ?: ""
                                val js = cleanAndExtractStalkerArray(body)
                                if (js != null && js.length() > 0) {
                                    for (i in 0 until js.length()) {
                                        val obj = js.optJSONObject(i) ?: continue
                                        val name = obj.optString("name").ifEmpty { obj.optString("title").ifEmpty { obj.optString("caption").ifEmpty { obj.optString("channel_name").ifEmpty { "Canal ${i + 1}" } } } }
                                        val stalkerId = obj.optString("id").ifEmpty { obj.optString("ch_id").ifEmpty { obj.optString("channel_id").ifEmpty { obj.optString("number") } } }
                                        val cmd = obj.optString("cmd").ifEmpty { obj.optString("url").ifEmpty { obj.optString("stream_url").ifEmpty { obj.optString("ch_id").ifEmpty { obj.optString("id").ifEmpty { obj.optString("number") } } } } }
                                        val logo = obj.optString("logo")
                                        val genreId = obj.optString("tv_genre_id")
                                        val genreName = genreMap[genreId]?.trim() ?: "Genre $genreId"
                                        val groupName = if (genreName.isEmpty() || genreName == "0" || genreName.equals("null", ignoreCase = true) || genreName.contains("genre: null", ignoreCase = true) || genreName.contains("genre null", ignoreCase = true) || genreName.equals("Genre null", ignoreCase = true)) "Général" else genreName
                                        val tvArchive = obj.optInt("tv_archive", 0)
                                        val tvArchiveDuration = obj.optInt("tv_archive_duration", 0)
                                        val tvArchiveType = obj.optString("tv_archive_type", "")
                                        val allowLocalTimeshift = obj.optInt("allow_local_timeshift", 0)
                                        val archiveDate = obj.optString("archive_date", "")
                                        val allowPvr = obj.optInt("allow_pvr", 0)
                                        val hasCatchup = (tvArchive == 1 || tvArchive > 0 || tvArchiveDuration > 0)
                                        val catchupDurationDays = if (tvArchiveDuration >= 24) {
                                            tvArchiveDuration / 24
                                        } else if (tvArchiveDuration > 0) {
                                            tvArchiveDuration
                                        } else if (hasCatchup) {
                                            3
                                        } else {
                                            0
                                        }
                                        
                                        val streamUrl = cmd.ifEmpty { stalkerId }
                                        
                                        if (streamUrl.isNotEmpty() || name.isNotEmpty()) {
                                            channels.add(
                                                ChannelItem(
                                                    playlistId = playlistId,
                                                    name = name,
                                                    logoUrl = logo,
                                                    streamUrl = streamUrl.ifEmpty { "${i + 1}" },
                                                    groupName = groupName,
                                                    type = "Live",
                                                    hasCatchup = hasCatchup,
                                                    catchupDurationDays = catchupDurationDays,
                                                    tvArchiveDuration = tvArchiveDuration,
                                                    tvArchiveType = tvArchiveType,
                                                    allowLocalTimeshift = allowLocalTimeshift,
                                                    archiveDate = archiveDate,
                                                    allowPvr = allowPvr,
                                                    stalkerId = stalkerId.ifEmpty { "${i + 1}" }
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    } catch (e: Throwable) {
                        Log.e("StalkerRepository", "Failed to fetch Stalker channels with $ep ($action): ${e.message}")
                    }
                }
            }
            
            // Fallback 1 : get_ordered_list par genre, pour SUPPLÉER get_all_channels.
            // IMPORTANT : get_all_channels peut réussir globalement (des milliers de chaînes)
            // tout en omettant certains genres spécifiques (ex: contenu adulte, censored=1)
            // qui ne remontent QUE via get_ordered_list&genre=X (comme le fait STBEMU).
            // On ne relance donc plus cette boucle uniquement quand channels est vide :
            // on identifie aussi les genres du catalogue absents des chaînes déjà récupérées,
            // et on va chercher UNIQUEMENT ceux-là en complément (pas les 353 genres à chaque fois).
            val alreadyCoveredGenreNames = channels.map { it.groupName.trim().lowercase() }.toHashSet()
            val missingGenres = genreMap.filter { (genreId, genreName) ->
                !isGenericCategory(genreName) && genreId.trim() != "*" &&
                    genreName.trim().lowercase() !in alreadyCoveredGenreNames
            }
            val genresToFetch = if (channels.isEmpty()) genreMap else missingGenres
            if (genresToFetch.isNotEmpty()) {
                onStatusUpdate("Synchronisation parallèle des catégories Live (${genresToFetch.size} genres)...")
                val genreSemaphore = kotlinx.coroutines.sync.Semaphore(5)
                val parallelGenreJobs = genresToFetch.entries.map { entry ->
                    async(Dispatchers.IO) {
                        genreSemaphore.withPermit {
                            val genreId = entry.key
                            val genreName = entry.value
                            val genreItems = mutableListOf<ChannelItem>()
                            var genreFetchSucceeded = false
                            for (ep in endpointsToTry) {
                                if (genreFetchSucceeded) break
                                try {
                                    var currentPage = 1
                                    var totalPages = 1
                                    var itemsAddedForThisGenre = 0
                                    while (currentPage <= totalPages) {
                                        val genreChannelsUrl = "${cleanUrl}${ep}?type=itv&action=get_ordered_list&genre=$genreId&p=$currentPage&token=$token&JsHttpRequest=1-xml"
                                        val requestBuilder = Request.Builder().url(genreChannelsUrl)
                                        addStalkerHeaders(requestBuilder, formattedMac, cleanUrl, token)
                                        val request = requestBuilder.build()
                                        client.newCall(request).execute().use { response ->
                                            if (response.isSuccessful) {
                                                val body = response.body?.string() ?: ""
                                                try {
                                                    val cleanedBody = cleanStalkerJson(body)
                                                    if (cleanedBody.startsWith("{")) {
                                                        val jsObj = JSONObject(cleanedBody).optJSONObject("js")
                                                        val totalItems = jsObj?.optInt("total_items", 0) ?: 0
                                                        val maxPageItems = jsObj?.optInt("max_page_items", 0) ?: 0
                                                        if (currentPage == 1 && totalItems > 0 && maxPageItems > 0) {
                                                            totalPages = ((totalItems + maxPageItems - 1) / maxPageItems).coerceAtMost(200)
                                                        }
                                                    }
                                                } catch (_: Exception) { }

                                                val js = cleanAndExtractStalkerArray(body)
                                                if (js != null && js.length() > 0) {
                                                    genreFetchSucceeded = true
                                                    for (i in 0 until js.length()) {
                                                        val obj = js.optJSONObject(i) ?: continue
                                                        val name = obj.optString("name")
                                                        val cmd = obj.optString("cmd")
                                                        val logo = obj.optString("logo")
                                                        val groupName = if (genreName.isEmpty() || genreName == "0" || genreName.equals("null", ignoreCase = true) || genreName.contains("genre: null", ignoreCase = true) || genreName.contains("genre null", ignoreCase = true) || genreName.equals("Genre null", ignoreCase = true)) "Général" else genreName

                                                        val stalkerId = obj.optString("id", "")
                                                        val tvArchive = obj.optInt("tv_archive", 0)
                                                        val tvArchiveDuration = obj.optInt("tv_archive_duration", 0)
                                                        val tvArchiveType = obj.optString("tv_archive_type", "")
                                                        val allowLocalTimeshift = obj.optInt("allow_local_timeshift", 0)
                                                        val archiveDate = obj.optString("archive_date", "")
                                                        val allowPvr = obj.optInt("allow_pvr", 0)
                                                        val hasCatchup = (tvArchive == 1 || tvArchive > 0 || tvArchiveDuration > 0)
                                                        val catchupDurationDays = if (tvArchiveDuration >= 24) tvArchiveDuration / 24 else if (tvArchiveDuration > 0) tvArchiveDuration else if (hasCatchup) 3 else 0

                                                        val streamUrl = cmd
                                                        if (streamUrl.isNotEmpty()) {
                                                            itemsAddedForThisGenre++
                                                            genreItems.add(
                                                                ChannelItem(
                                                                    playlistId = playlistId,
                                                                    name = name,
                                                                    logoUrl = logo,
                                                                    streamUrl = streamUrl,
                                                                    groupName = groupName,
                                                                    type = "Live",
                                                                    hasCatchup = hasCatchup,
                                                                    catchupDurationDays = catchupDurationDays,
                                                                    tvArchiveDuration = tvArchiveDuration,
                                                                    tvArchiveType = tvArchiveType,
                                                                    allowLocalTimeshift = allowLocalTimeshift,
                                                                    archiveDate = archiveDate,
                                                                    allowPvr = allowPvr,
                                                                    stalkerId = stalkerId
                                                                )
                                                            )
                                                        }
                                                    }
                                                } else if (currentPage == 1) {
                                                    totalPages = 0
                                                }
                                            }
                                        }
                                        currentPage++
                                    }
                                    if (genreFetchSucceeded) {
                                        Log.d("StalkerRepository", "Genre '$genreName' (id=$genreId) : $itemsAddedForThisGenre chaînes récupérées via $ep")
                                    }
                                } catch (e: Exception) {
                                    Log.e("StalkerRepository", "Failed to fetch genre $genreId channels: ${e.message}")
                                }
                            }
                            genreItems
                        }
                    }
                }
                val allParallelLiveChannels = parallelGenreJobs.awaitAll().flatten()
                channels.addAll(allParallelLiveChannels)
            }

            // Fallback 2: Direct paginated fetch if channels still empty
            if (channels.isEmpty()) {
                onStatusUpdate("Téléchargement direct des chaînes Live par pages...")
                for (ep in endpointsToTry) {
                    if (channels.isNotEmpty()) break
                    var page = 1
                    var emptyStreak = 0
                    while (page <= 50 && emptyStreak < 2) {
                        try {
                            val pageUrl = "${cleanUrl}${ep}?type=itv&action=get_ordered_list&p=$page&token=$token&JsHttpRequest=1-xml"
                            val requestBuilder = Request.Builder().url(pageUrl)
                            addStalkerHeaders(requestBuilder, formattedMac, cleanUrl, token)
                            val request = requestBuilder.build()
                            client.newCall(request).execute().use { response ->
                                if (response.isSuccessful) {
                                    val body = response.body?.string() ?: ""
                                    val js = cleanAndExtractStalkerArray(body)
                                    if (js != null && js.length() > 0) {
                                        emptyStreak = 0
                                        for (i in 0 until js.length()) {
                                            val obj = js.optJSONObject(i) ?: continue
                                            val name = obj.optString("name")
                                            val cmd = obj.optString("cmd")
                                            val logo = obj.optString("logo")
                                            val genreId = obj.optString("tv_genre_id")
                                            val genreName = genreMap[genreId]?.trim() ?: "Général"
                                            val stalkerId = obj.optString("id", "")
                                            val tvArchive = obj.optInt("tv_archive", 0)
                                            val tvArchiveDuration = obj.optInt("tv_archive_duration", 0)
                                            val tvArchiveType = obj.optString("tv_archive_type", "")
                                            val allowLocalTimeshift = obj.optInt("allow_local_timeshift", 0)
                                            val archiveDate = obj.optString("archive_date", "")
                                            val allowPvr = obj.optInt("allow_pvr", 0)
                                            val hasCatchup = (tvArchive == 1 || tvArchive > 0 || tvArchiveDuration > 0)
                                            val catchupDurationDays = if (tvArchiveDuration >= 24) tvArchiveDuration / 24 else if (tvArchiveDuration > 0) tvArchiveDuration else if (hasCatchup) 3 else 0
                                            val streamUrl = cmd
                                            if (streamUrl.isNotEmpty()) {
                                                channels.add(
                                                    ChannelItem(
                                                        playlistId = playlistId,
                                                        name = name,
                                                        logoUrl = logo,
                                                        streamUrl = streamUrl,
                                                        groupName = genreName,
                                                        type = "Live",
                                                        hasCatchup = hasCatchup,
                                                        catchupDurationDays = catchupDurationDays,
                                                        tvArchiveDuration = tvArchiveDuration,
                                                        tvArchiveType = tvArchiveType,
                                                        allowLocalTimeshift = allowLocalTimeshift,
                                                        archiveDate = archiveDate,
                                                        allowPvr = allowPvr,
                                                        stalkerId = stalkerId
                                                    )
                                                )
                                            }
                                        }
                                    } else {
                                        emptyStreak++
                                    }
                                } else {
                                    emptyStreak++
                                }
                            }
                        } catch (e: Exception) {
                            emptyStreak++
                        }
                        page++
                    }
                }
            }
        }
        
        // 2. Fetch Movies & Series based on selection
        val globalSeenIds = mutableSetOf<String>()
        if (loadMovies) {
            onStatusUpdate("Téléchargement des Films Stalker VOD...")
            try {
                val movies = fetchCompleteStalkerItems(
                    client = client,
                    cleanUrl = cleanUrl,
                    token = token,
                    macAddress = formattedMac,
                    playlistId = playlistId,
                    actionType = "vod",
                    type = "Movie",
                    defaultGroupName = "Films",
                    endpointPath = endpointPath,
                    pagesCounter = pagesCounter,
                    globalSeenIds = globalSeenIds,
                    onStatusUpdate = onStatusUpdate
                )
                channels.addAll(movies)
            } catch (e: Exception) {
                Log.e("StalkerRepository", "Failed to fetch Stalker VOD: ${e.message}")
            }
        }

        if (loadSeries) {
            onStatusUpdate("Téléchargement des Séries Stalker...")
            try {
                val series = fetchCompleteStalkerItems(
                    client = client,
                    cleanUrl = cleanUrl,
                    token = token,
                    macAddress = formattedMac,
                    playlistId = playlistId,
                    actionType = "series",
                    type = "Series",
                    defaultGroupName = "Séries",
                    endpointPath = endpointPath,
                    pagesCounter = pagesCounter,
                    globalSeenIds = globalSeenIds,
                    onStatusUpdate = onStatusUpdate
                )
                channels.addAll(series)
            } catch (e: Exception) {
                Log.e("StalkerRepository", "Failed to fetch Stalker series: ${e.message}")
            }
        }
        
        val liveCount = channels.count { it.type == "Live" }
        val vodCount = channels.count { it.type == "Movie" }
        val seriesCount = channels.count { it.type == "Series" }

        if (liveCount == 0 && vodCount == 0 && seriesCount == 0) {
            db.playlistDao().deletePlaylist(playlistId)
            throw Exception("Le portail a répondu mais n'a retourné aucun canal")
        }
        db.channelDao().deleteChannelsByPlaylist(playlistId)
        db.channelDao().insertChannels(channels)

        val totalLiveCount = channels.count { it.type == "Live" }
        val totalMoviesCount = channels.count { it.type == "Movie" }
        val totalSeriesCount = channels.count { it.type == "Series" }

        Log.d("STALKER_SYNC_SUMMARY", "--- CATALOGUE SYNC RECAP ---")
        Log.d("STALKER_SYNC_SUMMARY", "Total items retrieved: ${channels.size} (Live: $totalLiveCount, VOD: $totalMoviesCount, Series: $totalSeriesCount)")
        Log.d("STALKER_SYNC_SUMMARY", "Pages traversed: ${pagesCounter.get()}")
        Log.d("STALKER_SYNC_SUMMARY", "Saisons détectées: N/A (Catalogue items)")
        Log.d("STALKER_SYNC_SUMMARY", "----------------------------")

        playlistId
      }
    }

    suspend fun reimportStalkerPortalData(
        playlistId: Long,
        portalUrl: String,
        macAddress: String,
        loadLive: Boolean = true,
        loadMovies: Boolean = true,
        loadSeries: Boolean = true,
        onStatusUpdate: (String) -> Unit = {}
    ): Int = withContext(Dispatchers.IO) {
      withStalkerWakeLock {
        ApiService.resetHandshakeCounter()
        onStatusUpdate("Connexion au portail Stalker...")
        val formattedMac = formatMacAddress(macAddress)
        val pathInfo = resolveStalkerPath(portalUrl, formattedMac)
        var resolvedUrl = pathInfo.baseUrl
        val endpointPath = pathInfo.endpointFile
        val endpointsToTry = listOf(endpointPath, "server/load.php", "portal.php", "load.php", "c/server/load.php", "c/portal.php", "c/load.php").distinct()

        val handshakeRes = apiService.executeSingleSyncHandshake(formattedMac, resolvedUrl, null)
        val token = handshakeRes.token
        resolvedUrl = handshakeRes.resolvedUrl

        val totalHandshakes = ApiService.getHandshakeCount()
        Log.d("StalkerRepository", "Nombre TOTAL de tentatives de handshake effectuées pour cette synchronisation : $totalHandshakes")
        Log.d("StalkerRepository", "Handshake unique obtenu, token=$token, baseUrl=$resolvedUrl, lancement des récupérations de contenu")
        Log.d("StalkerRepository", "Temporisation de 300ms avant le premier appel de contenu...")
        kotlinx.coroutines.delay(300)

        // Update URL and MAC in database if it resolved to fallback
        val currentPlaylist = db.playlistDao().getPlaylistById(playlistId)
        if (currentPlaylist != null && (currentPlaylist.url != resolvedUrl || currentPlaylist.macAddress != formattedMac)) {
            db.playlistDao().updatePlaylist(currentPlaylist.copy(url = resolvedUrl, macAddress = formattedMac))
        }
        
        val channels = mutableListOf<ChannelItem>()
        val cleanUrl = resolvedUrl
        val syncSession = StalkerSyncSession(token, resolvedUrl, formattedMac, null, apiService)
        val client = getUnsafeOkHttpClientWithoutInterceptor().newBuilder()
            .addInterceptor(StalkerSyncSessionInterceptor(syncSession))
            .build()

        // Fetch genres/categories & live channels if loadLive is checked
        if (loadLive) {
            onStatusUpdate("Récupération des catégories...")
            val genreMap = fetchStalkerGenres(client, cleanUrl, token, formattedMac, endpointPath)
            
            onStatusUpdate("Téléchargement des chaînes Live...")
            val liveActionsToTry = listOf("get_all_channels", "get_itv_channels", "get_ordered_list&genre=*", "get_ordered_list&genre=0", "get_ordered_list", "get_all_channels&force_ch_link_check=0")
            for (ep in endpointsToTry) {
                if (channels.isNotEmpty()) break
                for (action in liveActionsToTry) {
                    if (channels.isNotEmpty()) break
                    try {
                        val channelsUrl = "${cleanUrl}${ep}?type=itv&action=$action&token=$token&JsHttpRequest=1-xml"
                        val requestBuilder = Request.Builder().url(channelsUrl)
                        addStalkerHeaders(requestBuilder, formattedMac, cleanUrl, token)
                        val request = requestBuilder.build()
                            
                        client.newCall(request).execute().use { response ->
                            if (response.isSuccessful) {
                                val body = response.body?.string() ?: ""
                                val js = cleanAndExtractStalkerArray(body)
                                if (js != null && js.length() > 0) {
                                    for (i in 0 until js.length()) {
                                        val obj = js.optJSONObject(i) ?: continue
                                        val name = obj.optString("name").ifEmpty { obj.optString("title").ifEmpty { obj.optString("caption").ifEmpty { obj.optString("channel_name").ifEmpty { "Canal ${i + 1}" } } } }
                                        val stalkerId = obj.optString("id").ifEmpty { obj.optString("ch_id").ifEmpty { obj.optString("channel_id").ifEmpty { obj.optString("number") } } }
                                        val cmd = obj.optString("cmd").ifEmpty { obj.optString("url").ifEmpty { obj.optString("stream_url").ifEmpty { obj.optString("ch_id").ifEmpty { obj.optString("id").ifEmpty { obj.optString("number") } } } } }
                                        val logo = obj.optString("logo")
                                        val genreId = obj.optString("tv_genre_id")
                                        val genreName = genreMap[genreId]?.trim() ?: "Genre $genreId"
                                        val groupName = if (genreName.isEmpty() || genreName == "0" || genreName.equals("null", ignoreCase = true) || genreName.contains("genre: null", ignoreCase = true) || genreName.contains("genre null", ignoreCase = true) || genreName.equals("Genre null", ignoreCase = true)) "Général" else genreName
                                        val tvArchive = obj.optInt("tv_archive", 0)
                                        val tvArchiveDuration = obj.optInt("tv_archive_duration", 0)
                                        val tvArchiveType = obj.optString("tv_archive_type", "")
                                        val allowLocalTimeshift = obj.optInt("allow_local_timeshift", 0)
                                        val archiveDate = obj.optString("archive_date", "")
                                        val allowPvr = obj.optInt("allow_pvr", 0)
                                        val hasCatchup = (tvArchive == 1 || tvArchive > 0 || tvArchiveDuration > 0)
                                        val catchupDurationDays = if (tvArchiveDuration >= 24) tvArchiveDuration / 24 else if (tvArchiveDuration > 0) tvArchiveDuration else if (hasCatchup) 3 else 0
                                        
                                        val streamUrl = cmd.ifEmpty { stalkerId }
                                        
                                        if (streamUrl.isNotEmpty() || name.isNotEmpty()) {
                                            channels.add(
                                                ChannelItem(
                                                    playlistId = playlistId,
                                                    name = name,
                                                    logoUrl = logo,
                                                    streamUrl = streamUrl.ifEmpty { "${i + 1}" },
                                                    groupName = groupName,
                                                    type = "Live",
                                                    hasCatchup = hasCatchup,
                                                    catchupDurationDays = catchupDurationDays,
                                                    tvArchiveDuration = tvArchiveDuration,
                                                    tvArchiveType = tvArchiveType,
                                                    allowLocalTimeshift = allowLocalTimeshift,
                                                    archiveDate = archiveDate,
                                                    allowPvr = allowPvr,
                                                    stalkerId = stalkerId.ifEmpty { "${i + 1}" }
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    } catch (e: Throwable) {
                        Log.e("StalkerRepository", "Failed to fetch Stalker channels with $ep ($action): ${e.message}")
                    }
                }
            }
            
            // Fallback 1 : get_ordered_list par genre, pour SUPPLÉER get_all_channels.
            // IMPORTANT : get_all_channels peut réussir globalement (des milliers de chaînes)
            // tout en omettant certains genres spécifiques (ex: contenu adulte, censored=1)
            // qui ne remontent QUE via get_ordered_list&genre=X (comme le fait STBEMU).
            // On ne relance donc plus cette boucle uniquement quand channels est vide :
            // on identifie aussi les genres du catalogue absents des chaînes déjà récupérées,
            // et on va chercher UNIQUEMENT ceux-là en complément (pas les 353 genres à chaque fois).
            val alreadyCoveredGenreNames = channels.map { it.groupName.trim().lowercase() }.toHashSet()
            val missingGenres = genreMap.filter { (genreId, genreName) ->
                !isGenericCategory(genreName) && genreId.trim() != "*" &&
                    genreName.trim().lowercase() !in alreadyCoveredGenreNames
            }
            val genresToFetch = if (channels.isEmpty()) genreMap else missingGenres
            if (genresToFetch.isNotEmpty()) {
                onStatusUpdate("Synchronisation parallèle des catégories Live (${genresToFetch.size} genres)...")
                val genreSemaphore = kotlinx.coroutines.sync.Semaphore(5)
                val parallelGenreJobs = genresToFetch.entries.map { entry ->
                    async(Dispatchers.IO) {
                        genreSemaphore.withPermit {
                            val genreId = entry.key
                            val genreName = entry.value
                            val genreItems = mutableListOf<ChannelItem>()
                            var genreFetchSucceeded = false
                            for (ep in endpointsToTry) {
                                if (genreFetchSucceeded) break
                                try {
                                    var currentPage = 1
                                    var totalPages = 1
                                    var itemsAddedForThisGenre = 0
                                    while (currentPage <= totalPages) {
                                        val genreChannelsUrl = "${cleanUrl}${ep}?type=itv&action=get_ordered_list&genre=$genreId&p=$currentPage&token=$token&JsHttpRequest=1-xml"
                                        val requestBuilder = Request.Builder().url(genreChannelsUrl)
                                        addStalkerHeaders(requestBuilder, formattedMac, cleanUrl, token)
                                        val request = requestBuilder.build()
                                        client.newCall(request).execute().use { response ->
                                            if (response.isSuccessful) {
                                                val body = response.body?.string() ?: ""
                                                try {
                                                    val cleanedBody = cleanStalkerJson(body)
                                                    if (cleanedBody.startsWith("{")) {
                                                        val jsObj = JSONObject(cleanedBody).optJSONObject("js")
                                                        val totalItems = jsObj?.optInt("total_items", 0) ?: 0
                                                        val maxPageItems = jsObj?.optInt("max_page_items", 0) ?: 0
                                                        if (currentPage == 1 && totalItems > 0 && maxPageItems > 0) {
                                                            totalPages = ((totalItems + maxPageItems - 1) / maxPageItems).coerceAtMost(200)
                                                        }
                                                    }
                                                } catch (_: Exception) { }

                                                val js = cleanAndExtractStalkerArray(body)
                                                if (js != null && js.length() > 0) {
                                                    genreFetchSucceeded = true
                                                    for (i in 0 until js.length()) {
                                                        val obj = js.optJSONObject(i) ?: continue
                                                        val name = obj.optString("name")
                                                        val cmd = obj.optString("cmd")
                                                        val logo = obj.optString("logo")
                                                        val groupName = if (genreName.isEmpty() || genreName == "0" || genreName.equals("null", ignoreCase = true) || genreName.contains("genre: null", ignoreCase = true) || genreName.contains("genre null", ignoreCase = true) || genreName.equals("Genre null", ignoreCase = true)) "Général" else genreName

                                                        val stalkerId = obj.optString("id", "")
                                                        val tvArchive = obj.optInt("tv_archive", 0)
                                                        val tvArchiveDuration = obj.optInt("tv_archive_duration", 0)
                                                        val tvArchiveType = obj.optString("tv_archive_type", "")
                                                        val allowLocalTimeshift = obj.optInt("allow_local_timeshift", 0)
                                                        val archiveDate = obj.optString("archive_date", "")
                                                        val allowPvr = obj.optInt("allow_pvr", 0)
                                                        val hasCatchup = (tvArchive == 1 || tvArchive > 0 || tvArchiveDuration > 0)
                                                        val catchupDurationDays = if (tvArchiveDuration >= 24) tvArchiveDuration / 24 else if (tvArchiveDuration > 0) tvArchiveDuration else if (hasCatchup) 3 else 0

                                                        val streamUrl = cmd
                                                        if (streamUrl.isNotEmpty()) {
                                                            itemsAddedForThisGenre++
                                                            genreItems.add(
                                                                ChannelItem(
                                                                    playlistId = playlistId,
                                                                    name = name,
                                                                    logoUrl = logo,
                                                                    streamUrl = streamUrl,
                                                                    groupName = groupName,
                                                                    type = "Live",
                                                                    hasCatchup = hasCatchup,
                                                                    catchupDurationDays = catchupDurationDays,
                                                                    tvArchiveDuration = tvArchiveDuration,
                                                                    tvArchiveType = tvArchiveType,
                                                                    allowLocalTimeshift = allowLocalTimeshift,
                                                                    archiveDate = archiveDate,
                                                                    allowPvr = allowPvr,
                                                                    stalkerId = stalkerId
                                                                )
                                                            )
                                                        }
                                                    }
                                                } else if (currentPage == 1) {
                                                    totalPages = 0
                                                }
                                            }
                                        }
                                        currentPage++
                                    }
                                    if (genreFetchSucceeded) {
                                        Log.d("StalkerRepository", "Genre '$genreName' (id=$genreId) : $itemsAddedForThisGenre chaînes récupérées via $ep")
                                    }
                                } catch (e: Exception) {
                                    Log.e("StalkerRepository", "Failed to fetch genre $genreId channels: ${e.message}")
                                }
                            }
                            genreItems
                        }
                    }
                }
                val allParallelLiveChannels = parallelGenreJobs.awaitAll().flatten()
                channels.addAll(allParallelLiveChannels)
            }

            // Fallback 2 for live channels if channels still empty
            if (channels.isEmpty()) {
                onStatusUpdate("Téléchargement direct des chaînes Live par pages...")
                for (ep in endpointsToTry) {
                    if (channels.isNotEmpty()) break
                    var page = 1
                    var emptyStreak = 0
                    while (page <= 50 && emptyStreak < 2) {
                        try {
                            val pageUrl = "${cleanUrl}${ep}?type=itv&action=get_ordered_list&p=$page&token=$token&JsHttpRequest=1-xml"
                            val requestBuilder = Request.Builder().url(pageUrl)
                            addStalkerHeaders(requestBuilder, formattedMac, cleanUrl, token)
                            val request = requestBuilder.build()
                            client.newCall(request).execute().use { response ->
                                if (response.isSuccessful) {
                                    val body = response.body?.string() ?: ""
                                    val js = cleanAndExtractStalkerArray(body)
                                    if (js != null && js.length() > 0) {
                                        emptyStreak = 0
                                        for (i in 0 until js.length()) {
                                            val obj = js.optJSONObject(i) ?: continue
                                            val name = obj.optString("name")
                                            val cmd = obj.optString("cmd")
                                            val logo = obj.optString("logo")
                                            val genreId = obj.optString("tv_genre_id")
                                            val genreName = genreMap[genreId]?.trim() ?: "Général"
                                            val stalkerId = obj.optString("id", "")
                                            val tvArchive = obj.optInt("tv_archive", 0)
                                            val tvArchiveDuration = obj.optInt("tv_archive_duration", 0)
                                            val tvArchiveType = obj.optString("tv_archive_type", "")
                                            val allowLocalTimeshift = obj.optInt("allow_local_timeshift", 0)
                                            val archiveDate = obj.optString("archive_date", "")
                                            val allowPvr = obj.optInt("allow_pvr", 0)
                                            val hasCatchup = (tvArchive == 1 || tvArchive > 0 || tvArchiveDuration > 0)
                                            val catchupDurationDays = if (tvArchiveDuration >= 24) tvArchiveDuration / 24 else if (tvArchiveDuration > 0) tvArchiveDuration else if (hasCatchup) 3 else 0
                                            val streamUrl = cmd
                                            if (streamUrl.isNotEmpty()) {
                                                channels.add(
                                                    ChannelItem(
                                                        playlistId = playlistId,
                                                        name = name,
                                                        logoUrl = logo,
                                                        streamUrl = streamUrl,
                                                        groupName = genreName,
                                                        type = "Live",
                                                        hasCatchup = hasCatchup,
                                                        catchupDurationDays = catchupDurationDays,
                                                        tvArchiveDuration = tvArchiveDuration,
                                                        tvArchiveType = tvArchiveType,
                                                        allowLocalTimeshift = allowLocalTimeshift,
                                                        archiveDate = archiveDate,
                                                        allowPvr = allowPvr,
                                                        stalkerId = stalkerId
                                                    )
                                                )
                                            }
                                        }
                                    } else {
                                        emptyStreak++
                                    }
                                } else {
                                    emptyStreak++
                                }
                            }
                        } catch (e: Exception) {
                            emptyStreak++
                        }
                        page++
                    }
                }
            }
        }
        
        // Re-fetch movies & series based on selection
        if (loadMovies) {
            onStatusUpdate("Récupération des Films Stalker VOD...")
            try {
                val movies = fetchCompleteStalkerItems(
                    client = client,
                    cleanUrl = cleanUrl,
                    token = token,
                    macAddress = formattedMac,
                    playlistId = playlistId,
                    actionType = "vod",
                    type = "Movie",
                    defaultGroupName = "Films",
                    endpointPath = endpointPath,
                    pagesCounter = null,
                    onStatusUpdate = onStatusUpdate
                )
                channels.addAll(movies)
            } catch (e: Exception) {
                Log.e("StalkerRepository", "Failed to re-fetch Stalker VOD: ${e.message}")
            }
        }

        if (loadSeries) {
            onStatusUpdate("Récupération des Séries Stalker...")
            try {
                val series = fetchCompleteStalkerItems(
                    client = client,
                    cleanUrl = cleanUrl,
                    token = token,
                    macAddress = formattedMac,
                    playlistId = playlistId,
                    actionType = "series",
                    type = "Series",
                    defaultGroupName = "Séries",
                    endpointPath = endpointPath,
                    pagesCounter = null,
                    onStatusUpdate = onStatusUpdate
                )
                channels.addAll(series)
            } catch (e: Exception) {
                Log.e("StalkerRepository", "Failed to re-fetch Stalker series: ${e.message}")
            }
        }
        
        val liveCount = channels.count { it.type == "Live" }
        val vodCount = channels.count { it.type == "Movie" }
        val seriesCount = channels.count { it.type == "Series" }

        if (liveCount == 0 && vodCount == 0 && seriesCount == 0) {
            throw Exception("Le portail a répondu mais n'a retourné aucun canal")
        }
        db.channelDao().deleteChannelsByPlaylist(playlistId)
        db.channelDao().insertChannels(channels)

        val totalLiveCount = channels.count { it.type == "Live" }
        val totalMoviesCount = channels.count { it.type == "Movie" }
        val totalSeriesCount = channels.count { it.type == "Series" }

        Log.d("STALKER_SYNC_SUMMARY", "--- CATALOGUE SYNC RECAP ---")
        Log.d("STALKER_SYNC_SUMMARY", "Total items retrieved: ${channels.size} (Live: $totalLiveCount, VOD: $totalMoviesCount, Series: $totalSeriesCount)")
        Log.d("STALKER_SYNC_SUMMARY", "Pages traversed: N/A (Re-sync)")
        Log.d("STALKER_SYNC_SUMMARY", "Saisons détectées: N/A (Catalogue items)")
        Log.d("STALKER_SYNC_SUMMARY", "----------------------------")

        channels.size
      }
    }

    private fun fetchStalkerGenres(
        client: okhttp3.OkHttpClient,
        cleanUrl: String,
        token: String,
        formattedMac: String,
        endpointPath: String = "server/load.php"
    ): Map<String, String> {
        val genreMap = LinkedHashMap<String, String>()
        val pathInfo = resolveStalkerPath(cleanUrl, formattedMac, endpointPath)
        val baseUrl = pathInfo.baseUrl
        val activeEndpoint = pathInfo.endpointFile
        val actionsToTry = listOf("get_genres", "get_categories", "get_main_categories", "get_genres_list", "get_categories_list", "get_genres&force_show_all=1")
        val endpointsToTry = listOf(activeEndpoint, "server/load.php", "portal.php", "load.php", "c/server/load.php", "c/portal.php").distinct()
        val typesToTry = listOf("itv", "stb")
        
        for (ep in endpointsToTry) {
            for (t in typesToTry) {
                for (action in actionsToTry) {
                    try {
                        val genresUrl = "${baseUrl}${ep}?type=$t&action=$action&token=$token&JsHttpRequest=1-xml"
                        val requestBuilder = Request.Builder().url(genresUrl)
                        addStalkerHeaders(requestBuilder, formattedMac, baseUrl, token)
                        val request = requestBuilder.build()
                        
                        client.newCall(request).execute().use { response ->
                            if (response.isSuccessful) {
                                val body = response.body?.string() ?: ""
                                Log.d("StalkerRepository", "Fetched $action response using $ep (type=$t): $body")
                                val cleaned = cleanStalkerJson(body)
                                if (cleaned.isNotEmpty()) {
                                    if (cleaned.startsWith("[")) {
                                        val jsArr = JSONArray(cleaned)
                                        parseCategoriesJsonArray(jsArr, genreMap)
                                    } else if (cleaned.startsWith("{")) {
                                        val json = JSONObject(cleaned)
                                        parseCategoriesFromJsonObject(json, genreMap)
                                    }
                                }
                            } else {
                                Log.d("StalkerRepository", "Failed to fetch $action with $ep, status code ${response.code}")
                            }
                            Unit
                        }
                        if (genreMap.isNotEmpty()) {
                            Log.d("StalkerRepository", "Successfully fetched ${genreMap.size} ITV categories with action=$action, type=$t and ep=$ep")
                            return genreMap
                        }
                    } catch (e: Exception) {
                        Log.e("StalkerRepository", "Failed to fetch Stalker $action with $ep (type=$t): ${e.message}")
                    }
                }
            }
        }
        return genreMap
    }

    private fun addStalkerHeaders(builder: Request.Builder, mac: String, cleanUrl: String, token: String) {
        val playlist = db.playlistDao().getPlaylistByMac(mac)
        val customIp = (playlist?.customIp?.trim() ?: playlist?.ipAddress?.trim() ?: "").trim()
        val isValidIpv4 = { ip: String ->
            val regex = """^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$""".toRegex()
            regex.matches(ip)
        }
        val hasCustomIp = customIp.isNotEmpty() && isValidIpv4(customIp)

        val deviceFields = generateStalkerDeviceFields(mac)
        val devId = deviceFields["device_id"] ?: ""
        val devId2 = deviceFields["device_id2"] ?: ""
        val sig = deviceFields["signature"] ?: ""
        val serial = deviceFields["serial_number"] ?: ""

        val userCardVal = if (hasCustomIp) {
            "mac=$mac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial; ip=$customIp"
        } else {
            "mac=$mac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial"
        }

        builder
            .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
            .header("X-User-Card", userCardVal)
            .header("Cookie", "mac=$mac; stb_lang=en; timezone=Europe/Paris; token=$token")
            .header("Referer", if (cleanUrl.endsWith("/")) cleanUrl else "$cleanUrl/")
            .header("Accept", "*/*")
            .header("Authorization", "Bearer $token")

        if (hasCustomIp) {
            builder.header("X-Forwarded-For", customIp)
            builder.header("Client-IP", customIp)
            builder.header("X-Real-IP", customIp)
            builder.header("X-Forwarded-Host", customIp)
        } else {
            builder.removeHeader("X-Forwarded-For")
            builder.removeHeader("Client-IP")
            builder.removeHeader("X-Real-IP")
            builder.removeHeader("X-Forwarded-Host")
        }
    }

    private fun parseStalkerTimestamp(value: Any?): Long {
        if (value == null) return 0L
        return when (value) {
            is Number -> {
                val v = value.toLong()
                if (v < 100000000000L) v * 1000L else v
            }
            is String -> {
                val str = value.trim()
                val num = str.toLongOrNull()
                if (num != null) {
                    if (num < 100000000000L) num * 1000L else num
                } else {
                    try {
                        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.FRANCE)
                        sdf.timeZone = java.util.TimeZone.getTimeZone("Europe/Paris")
                        sdf.parse(str)?.time ?: 0L
                    } catch (e: Exception) {
                        0L
                    }
                }
            }
            else -> 0L
        }
    }

    suspend fun getArchiveEpg(
        playlistId: Long,
        stalkerId: String,
        hours: Int = 24
    ): List<EpgProgram> = withContext(Dispatchers.IO) {
        val playlist = db.playlistDao().getPlaylistById(playlistId) ?: return@withContext emptyList()
        val portalUrl = playlist.url
        val mac = playlist.macAddress ?: ""
        val pathInfo = resolveStalkerPath(portalUrl, mac)
        val cleanUrl = pathInfo.baseUrl
        val activeEndpoint = pathInfo.endpointFile

        val cleanChId = stalkerId.replace(Regex("[^0-9]"), "").ifEmpty { stalkerId }

        delay(400) // Anti-ban rate limiting delay

        var token = ""
        try {
            token = apiService.authenticateStalker(mac, portalUrl)
        } catch (e: Exception) {
            Log.e("StalkerRepository", "Failed to authenticate Stalker for EPG: ${e.message}")
            return@withContext emptyList()
        }

        val client = getUnsafeOkHttpClient()
        val programs = mutableListOf<EpgProgram>()

        val endpointsToTry = listOf(
            "${cleanUrl}${activeEndpoint}?type=itv&action=get_archive&ch_id=$cleanChId&token=$token&JsHttpRequest=1-xml",
            "${cleanUrl}${activeEndpoint}?type=itv&action=get_archive&channel_id=$cleanChId&token=$token&JsHttpRequest=1-xml",
            "${cleanUrl}${activeEndpoint}?type=itv&action=get_epg&ch_id=$cleanChId&period=$hours&token=$token&JsHttpRequest=1-xml",
            "${cleanUrl}${activeEndpoint}?type=itv&action=get_short_epg&ch_id=$cleanChId&size=100&token=$token&JsHttpRequest=1-xml"
        )

        val startSdf = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).apply {
            timeZone = java.util.TimeZone.getDefault()
        }

        for (epgUrl in endpointsToTry) {
            val request = Request.Builder().url(epgUrl).apply {
                addStalkerHeaders(this, mac, cleanUrl, token)
            }.build()

            try {
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string().orEmpty()
                        val jsArr = cleanAndExtractStalkerArray(body)
                        if (jsArr != null && jsArr.length() > 0) {
                            for (i in 0 until jsArr.length()) {
                                val obj = jsArr.optJSONObject(i) ?: continue
                                val title = obj.optString("name").ifEmpty { obj.optString("title").ifEmpty { obj.optString("o_name", "No Title") } }
                                if (title.isEmpty() || title == "No Title") continue
                                val desc = obj.optString("descr").ifEmpty { obj.optString("description", "") }

                                val startVal = if (obj.has("t_start")) obj.opt("t_start")
                                else if (obj.has("start_timestamp")) obj.opt("start_timestamp")
                                else if (obj.has("time")) obj.opt("time")
                                else if (obj.has("real_start")) obj.opt("real_start")
                                else if (obj.has("start")) obj.opt("start")
                                else null

                                val stopVal = if (obj.has("t_end")) obj.opt("t_end")
                                else if (obj.has("stop_timestamp")) obj.opt("stop_timestamp")
                                else if (obj.has("time_to")) obj.opt("time_to")
                                else if (obj.has("real_end")) obj.opt("real_end")
                                else if (obj.has("end")) obj.opt("end")
                                else null

                                val startMs = parseStalkerTimestamp(startVal)
                                var endMs = parseStalkerTimestamp(stopVal)
                                if (startMs <= 0L) continue
                                if (endMs <= startMs) endMs = startMs + 3600000L

                                val id = obj.optString("id").ifEmpty { obj.optString("real_id").ifEmpty { obj.optString("real_id_epg", "") } }.trim()

                                val startTimeStr = startSdf.format(java.util.Date(startMs))
                                val endTimeStr = startSdf.format(java.util.Date(endMs))

                                val startHour = java.util.Calendar.getInstance().apply { timeInMillis = startMs }.get(java.util.Calendar.HOUR_OF_DAY)
                                val endHour = java.util.Calendar.getInstance().apply { timeInMillis = endMs }.get(java.util.Calendar.HOUR_OF_DAY)

                                programs.add(
                                    EpgProgram(
                                        title = title,
                                        startTime = startTimeStr,
                                        endTime = endTimeStr,
                                        description = desc,
                                        startHour = startHour,
                                        endHour = endHour,
                                        startTimestamp = startMs,
                                        endTimestamp = endMs,
                                        id = id,
                                        realId = id,
                                        markArchive = 1
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("StalkerRepository", "Error loading EPG from $epgUrl: ${e.message}")
            }

            if (programs.isNotEmpty()) {
                Log.d("StalkerRepository", "Successfully loaded ${programs.size} EPG items from $epgUrl")
                break
            }
        }

        programs.distinctBy { it.startTimestamp }.sortedBy { it.startTimestamp }
    }

    // Détecte si l'URL résolue est en fait un lien de DIRECT (le portail a ignoré les
    // paramètres catch-up et renvoyé le cmd normal) plutôt qu'un vrai lien de replay.
    fun looksLikeLiveNotArchive(url: String, liveCmd: String = ""): Boolean {
        if (url.isBlank()) return true
        if (url.equals("false", ignoreCase = true) || url.equals("null", ignoreCase = true)) return true

        if (liveCmd.isNotBlank()) {
            val cleanUrl = url.trim()
            val cleanLive = liveCmd.trim()
                .removePrefix("ffrt ")
                .removePrefix("ffmpeg ")
                .removePrefix("auto ")
                .removePrefix("standalone ")
                .trim()

            if (cleanUrl.equals(cleanLive, ignoreCase = true)) return true

            val lower = cleanUrl.lowercase()
            val hasArchiveIndicator = lower.contains("archive") ||
                    lower.contains("timeshift") ||
                    lower.contains("utc=") ||
                    lower.contains("lutc=") ||
                    lower.contains("duration=") ||
                    lower.contains("/media/") ||
                    lower.contains("real_id=") ||
                    lower.contains("series=") ||
                    lower.contains("/archive/") ||
                    lower.contains("/replay/") ||
                    lower.contains("/catchup/") ||
                    lower.contains("start=") ||
                    lower.contains("end=") ||
                    lower.contains("offset=") ||
                    lower.contains("dvr") ||
                    Regex("1[6-9][0-9]{8}").containsMatchIn(cleanUrl)

            if (hasArchiveIndicator) return false
            return true // Aucun indicateur d'archive -> c'est le flux LIVE, pas un vrai replay
        }
        return false
    }

    suspend fun resolveStalkerPlayLinkForArchive(
        playlistId: Long,
        cmd: String,
        startTimestamp: Long,
        stopTimestamp: Long = 0L,
        programId: String = "",
        channelStalkerId: String = ""
    ): String = withContext(Dispatchers.IO) {
        val playlist = db.playlistDao().getPlaylistById(playlistId) ?: return@withContext ""
        val portalUrl = playlist.url
        val mac = playlist.macAddress ?: ""
        val pathInfo = resolveStalkerPath(portalUrl, mac)
        val cleanUrl = pathInfo.baseUrl
        val activeEndpoint = pathInfo.endpointFile

        val rootDomain = portalUrl.substringBefore("/stalker_portal").substringBefore("/c/").substringBefore("/server").trimEnd('/')
        val stalkerBase = if (portalUrl.contains("/stalker_portal")) "$rootDomain/stalker_portal" else rootDomain

        delay(300) // Anti-ban rate limiting delay

        var token = ""
        try {
            token = apiService.authenticateStalker(mac, portalUrl)
        } catch (e: Exception) {
            Log.e("StalkerRepository", "Failed to authenticate Stalker for play link: ${e.message}")
            return@withContext ""
        }

        val client = getUnsafeOkHttpClient()
        val startSec = if (startTimestamp > 100000000000L) startTimestamp / 1000L else startTimestamp
        val stopSec = if (stopTimestamp > 100000000000L) stopTimestamp / 1000L else stopTimestamp
        val durSec = (stopSec - startSec).coerceAtLeast(60L)
        val durMin = (durSec / 60L).coerceAtLeast(1L)

        var cleanCmd = cmd.trim()
        if (cleanCmd.startsWith("ffrt ")) cleanCmd = cleanCmd.substring(5).trim()
        if (cleanCmd.startsWith("ffmpeg ")) cleanCmd = cleanCmd.substring(7).trim()
        if (cleanCmd.startsWith("auto ")) cleanCmd = cleanCmd.substring(5).trim()
        if (cleanCmd.startsWith("standalone ")) cleanCmd = cleanCmd.substring(11).trim()

        val cleanChId = channelStalkerId.replace(Regex("[^0-9]"), "").ifEmpty {
            cleanCmd.substringAfterLast("/").substringBefore(".").replace(Regex("[^0-9]"), "")
        }
        val cleanProgId = programId.trim().takeIf { it.isNotEmpty() && !it.matches(Regex("^[0-9]{12,}$")) } ?: ""

        val helperMakeAbs = { relUrl: String ->
            var u = relUrl.trim()
            if (u.startsWith("ffmpeg ")) u = u.substring(7).trim()
            if (u.startsWith("auto ")) u = u.substring(5).trim()
            if (u.startsWith("standalone ")) u = u.substring(11).trim()
            if (u.startsWith("ffrt ")) u = u.substring(5).trim()

            val isAbs = u.startsWith("http://") || u.startsWith("https://") || u.startsWith("rtmp://") || u.startsWith("rtsp://")
            var absUrl = when {
                isAbs -> u
                u.startsWith("/stalker_portal") -> "$rootDomain$u"
                u.startsWith("/") -> "$stalkerBase$u"
                else -> "$stalkerBase/$u"
            }
            if (!isAbs && !absUrl.contains("token=") && token.isNotEmpty() && !absUrl.startsWith("rtmp")) {
                absUrl = if (absUrl.contains("?")) "$absUrl&token=$token" else "$absUrl?token=$token"
            }
            absUrl
        }

        // 0. MÉTHODE FOXBLEU FINAL (GET load.php exact comme Reqable)
        if (cleanChId.isNotEmpty() && startSec > 0) {
            val effectiveStopSec = if (stopSec > startSec) stopSec else (startSec + durSec)
            val epgFoxBleu = EpgFoxBleu(
                ch_id = cleanChId,
                start_timestamp = startSec,
                stop_timestamp = effectiveStopSec
            )
            val finalReplayUrl = getReplayUrl_FoxBleu_Final(mac, token, epgFoxBleu, portalUrl)
            if (!finalReplayUrl.isNullOrEmpty()) {
                val abs = helperMakeAbs(finalReplayUrl)
                if (!looksLikeLiveNotArchive(abs, cleanCmd)) {
                    Log.d("CatchupDebug", "[FoxBleu Final GET] SUCCESS REPLAY URL: $abs")
                    return@withContext abs
                }
            }
        }

        // 0. MÉTHODE STBEMU POST DIRECT (FoxBleu / Deirnet / Ministra)
        if (cleanProgId.isNotEmpty()) {
            val epgCandidates = mutableListOf(cleanProgId)
            val cleanProgramIdOnly = cleanProgId.substringAfter("_").takeIf { it.isNotEmpty() && it != cleanProgId }
            if (cleanProgramIdOnly != null) {
                epgCandidates.add(cleanProgramIdOnly)
            }
            if (cleanChId.isNotEmpty() && !cleanProgId.endsWith("_$cleanChId")) {
                epgCandidates.add("${cleanProgId}_${cleanChId}")
            }

            for (epgCandidate in epgCandidates.distinct()) {
                val replayUrl = playReplayFoxBleu_NoFluxIndispo(
                    mac = mac,
                    token = token,
                    epgId = epgCandidate,
                    portalUrl = portalUrl
                )
                if (replayUrl.isNotEmpty()) {
                    val abs = helperMakeAbs(replayUrl)
                    if (!looksLikeLiveNotArchive(abs, cleanCmd)) {
                        Log.d("CatchupDebug", "[STBEmu FoxBleu] SUCCESS REPLAY URL: $abs")
                        return@withContext abs
                    }
                }
            }
        }

        // 1. MÉTHODE tv_archive
        // Le champ "id" du programme EPG (ex: "177500574_13847") est DÉJÀ composite
        // (<id_numérique>_<ch_id>) sur ce type de portail : ne PAS le reconcaténer avec cleanChId.
        val archiveCmdsToTry = mutableListOf<String>()
        val progIdAlreadyComposite = cleanProgId.contains("_") && cleanChId.isNotEmpty() && cleanProgId.endsWith("_$cleanChId")
        if (cleanProgId.isNotEmpty()) {
            archiveCmdsToTry.add("auto /media/${cleanProgId}.ts")
            if (!progIdAlreadyComposite && cleanChId.isNotEmpty()) {
                archiveCmdsToTry.add("auto /media/${cleanProgId}_${cleanChId}.ts")
            }
        }
        if (cleanChId.isNotEmpty() && startSec > 0) {
            archiveCmdsToTry.add("auto /media/${cleanChId}_${startSec}.ts")
        }

        val isPortalPhp = activeEndpoint.equals("portal.php", ignoreCase = true) || portalUrl.contains("portal.php", ignoreCase = true)
        val tokenParam = if (isPortalPhp) "" else "&token=$token"

        for (acmd in archiveCmdsToTry) {
            val encCmd = java.net.URLEncoder.encode(acmd, "UTF-8")
            val urlTvArchive = "${cleanUrl}${activeEndpoint}?type=tv_archive&action=create_link&cmd=$encCmd&series=&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml$tokenParam"
            Log.d("CatchupDebug", "[tv_archive] Tentative ($acmd): $urlTvArchive")
            try {
                val request = Request.Builder().url(urlTvArchive).apply {
                    addStalkerHeaders(this, mac, cleanUrl, token)
                }.build()
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string().orEmpty()
                        val resolved = parseStalkerPlayLink(body)
                        if (!resolved.isNullOrEmpty()) {
                            val abs = helperMakeAbs(resolved)
                            if (!looksLikeLiveNotArchive(abs, cleanCmd)) {
                                Log.d("CatchupDebug", "[tv_archive] SUCCÈS: $abs")
                                return@withContext abs
                            } else {
                                Log.w("CatchupDebug", "[tv_archive] Rejeté (ressemble au direct): $abs")
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("StalkerRepository", "[tv_archive] Erreur: ${e.message}")
            }
        }

        // 2. MÉTHODE itv (fallback)
        val cmdsToTry = mutableSetOf(cleanCmd)
        if (cmd.trim().isNotEmpty()) cmdsToTry.add(cmd.trim())
        if (cleanChId.isNotEmpty()) {
            cmdsToTry.add("auto /ch/${cleanChId}_")
            cmdsToTry.add("/ch/${cleanChId}_")
            cmdsToTry.add("ch_${cleanChId}")
            cmdsToTry.add(cleanChId)
        }

        val nowSecs = System.currentTimeMillis() / 1000L
        val timeshiftSec = if (startSec > 0L) (nowSecs - startSec).coerceAtLeast(60L) else 3600L

        for (c in cmdsToTry) {
            val encCmd = java.net.URLEncoder.encode(c, "UTF-8")
            val itvUrlsToTry = mutableListOf(
                "${cleanUrl}${activeEndpoint}?type=itv&action=create_link&cmd=$encCmd&archive=$startSec&duration=$durMin$tokenParam&JsHttpRequest=1-xml",
                "${cleanUrl}${activeEndpoint}?type=itv&action=create_link&cmd=$encCmd&archive=$startSec&duration=$durSec$tokenParam&JsHttpRequest=1-xml",
                "${cleanUrl}${activeEndpoint}?type=itv&action=create_link&cmd=$encCmd&utc=$startSec&lutc=$stopSec&duration=$durMin$tokenParam&JsHttpRequest=1-xml",
                "${cleanUrl}${activeEndpoint}?type=itv&action=create_link&cmd=$encCmd&archive=$startSec$tokenParam&JsHttpRequest=1-xml",
                "${cleanUrl}${activeEndpoint}?type=itv&action=create_link&cmd=$encCmd&timeshift=$timeshiftSec$tokenParam&JsHttpRequest=1-xml"
            )
            if (cleanProgId.isNotEmpty()) {
                val encProg = java.net.URLEncoder.encode(cleanProgId, "UTF-8")
                itvUrlsToTry.add("${cleanUrl}${activeEndpoint}?type=itv&action=create_link&cmd=$encCmd&series=$encProg$tokenParam&JsHttpRequest=1-xml")
                itvUrlsToTry.add("${cleanUrl}${activeEndpoint}?type=itv&action=create_link&cmd=$encCmd&real_id=$encProg$tokenParam&JsHttpRequest=1-xml")
                val encMediaCmd = java.net.URLEncoder.encode("auto /media/$cleanProgId.ts", "UTF-8")
                itvUrlsToTry.add("${cleanUrl}${activeEndpoint}?type=itv&action=create_link&cmd=$encMediaCmd$tokenParam&JsHttpRequest=1-xml")
            }
            if (cleanChId.isNotEmpty()) {
                itvUrlsToTry.add("${cleanUrl}${activeEndpoint}?type=itv&action=create_link&cmd=$encCmd&ch_id=$cleanChId&archive=$startSec&duration=$durMin$tokenParam&JsHttpRequest=1-xml")
            }

            for (url in itvUrlsToTry) {
                Log.d("CatchupDebug", "[itv+archive fallback] Tentative: $url")
                val request = Request.Builder().url(url).apply {
                    addStalkerHeaders(this, mac, cleanUrl, token)
                }.build()

                try {
                    client.newCall(request).execute().use { response ->
                        if (response.isSuccessful) {
                            val body = response.body?.string().orEmpty()
                            val resolved = parseStalkerPlayLink(body)
                            if (!resolved.isNullOrEmpty()) {
                                val abs = helperMakeAbs(resolved)
                                if (!looksLikeLiveNotArchive(abs, cleanCmd)) {
                                    Log.d("CatchupDebug", "[itv+archive fallback] SUCCÈS: $abs")
                                    return@withContext abs
                                } else {
                                    Log.w("CatchupDebug", "[itv+archive fallback] Rejeté: ressemble au lien du DIRECT: $abs")
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e("StalkerRepository", "Failed resolveStalkerPlayLinkForArchive: ${e.message}")
                }
            }
        }

        // 3. MÉTHODE FLUSSONIC / DIRECT STREAM URL FALLBACK
        // Si tv_archive et itv n'ont pas renvoyé de lien, de nombreux portails Stalker/Ministra
        // (comme FoxBleu, King365, OTT Platinum) fonctionnent en ajoutant &archive=...&duration=...
        // directement sur l'URL du flux direct résolue par le portail.
        try {
            val liveResolved = apiService.resolveStalkerStream(portalUrl, mac, "type=itv&action=create_link&cmd=${java.net.URLEncoder.encode(cmd, "UTF-8")}&forced_storage=0&disable_ad=0&JsHttpRequest=1-xml", "Live")
            if (!liveResolved.isNullOrEmpty() && (liveResolved.startsWith("http://") || liveResolved.startsWith("https://"))) {
                val sep = if (liveResolved.contains("?")) "&" else "?"
                val archiveUrl = "$liveResolved${sep}archive=$startSec&duration=$durMin"
                Log.d("CatchupDebug", "[Flussonic direct fallback] SUCCÈS: $archiveUrl")
                return@withContext archiveUrl
            }
        } catch (e: Exception) {
            Log.e("StalkerRepository", "[Flussonic direct fallback] Erreur: ${e.message}")
        }

        ""
    }

    private val tokenTimestamps = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private fun isTokenOld(mac: String, token: String): Boolean {
        if (token.isEmpty()) return true
        val lastTime = tokenTimestamps[mac] ?: 0L
        return (System.currentTimeMillis() - lastTime) > 300_000L // 5 min
    }

    suspend fun doHandshakeFoxBleu(mac: String, portalUrl: String = "http://foxbleu.pro/portal.php"): String = withContext(Dispatchers.IO) {
        try {
            val baseRoot = portalUrl.substringBefore("/stalker_portal").substringBefore("/c/").substringBefore("/server")
                .let { if (it.endsWith("/")) it else "$it/" }
            val handshakeUrl = "${baseRoot}portal.php?type=stb&action=handshake&JsHttpRequest=1-xml&token=&mac=$mac"
            val req = Request.Builder()
                .url(handshakeUrl)
                .get()
                .header("Cookie", "mac=$mac; stb_lang=en; timezone=GMT")
                .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) MAG200 stbapp ver: 4 rev: 1812")
                .header("Referer", baseRoot)
                .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                .build()

            val client = getUnsafeOkHttpClient()
            val resp = client.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            Log.d("FOX", "[doHandshakeFoxBleu] Reponse: $body")
            val cleaned = cleanStalkerJson(body)
            val json = try { JSONObject(cleaned) } catch (e: Exception) { null }
            val jsObj = json?.optJSONObject("js")
            val newToken = jsObj?.optString("token")?.ifEmpty { json?.optString("token") } ?: ""
            if (newToken.isNotEmpty()) {
                tokenTimestamps[mac] = System.currentTimeMillis()
                Log.d("FOX", "Nouveau token: $newToken")
                return@withContext newToken
            }
            val fallback = apiService.authenticateStalker(mac, portalUrl)
            if (fallback.isNotEmpty()) {
                tokenTimestamps[mac] = System.currentTimeMillis()
                Log.d("FOX", "Nouveau token fallback: $fallback")
                return@withContext fallback
            }
        } catch (e: Exception) {
            Log.e("FOX", "[doHandshakeFoxBleu] Erreur: ${e.message}")
            try {
                val fb = apiService.authenticateStalker(mac, portalUrl)
                if (fb.isNotEmpty()) {
                    tokenTimestamps[mac] = System.currentTimeMillis()
                    return@withContext fb
                }
            } catch (_: Exception) {}
        }
        ""
    }

    suspend fun playReplayFoxBleu_NoFluxIndispo(
        mac: String,
        token: String,
        epgId: String,
        portalUrl: String = "http://foxbleu.pro/portal.php"
    ): String = withContext(Dispatchers.IO) {
        var currentToken = token

        // 1. Si token a plus de 5 min, refais handshake comme STBEmu
        if (isTokenOld(mac, currentToken)) {
            val freshToken = doHandshakeFoxBleu(mac, portalUrl)
            if (freshToken.isNotEmpty()) {
                currentToken = freshToken
            }
            Log.d("FOX", "Nouveau token: $currentToken")
        }

        val cleanEpgId = if (epgId.startsWith("auto ") || epgId.startsWith("ffmpeg ")) {
            epgId.substringAfter(" ").substringBefore(".ts").substringAfterLast("/")
        } else {
            epgId
        }
        val cmd = "auto /media/$cleanEpgId.ts"

        val baseRoot = portalUrl.substringBefore("/stalker_portal").substringBefore("/c/").substringBefore("/server")
            .let { if (it.endsWith("/")) it else "$it/" }
        val url = "${baseRoot}portal.php"
        val client = getUnsafeOkHttpClient()

        repeat(2) { attempt -> // 2 tentatives comme STBEmu
            try {
                val form = okhttp3.FormBody.Builder()
                    .add("type", "itv")
                    .add("action", "create_link")
                    .add("cmd", cmd)
                    .add("JsHttpRequest", "1-xml")
                    .build()

                val req = Request.Builder()
                    .url(url)
                    .post(form)
                    .header("Cookie", "mac=$mac; stb_lang=en; timezone=GMT; token=$currentToken")
                    .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) MAG200 stbapp ver: 4 rev: 1812")
                    .header("Referer", baseRoot)
                    .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                    .build()

                val body = client.newCall(req).execute().body?.string() ?: ""
                Log.d("FOX_REPLAY", "Tentative $attempt - Reponse: $body")

                val jsCmd = parseStalkerPlayLink(body) ?: ""

                if (jsCmd.isNotEmpty() && (jsCmd.startsWith("http") || jsCmd.contains("://"))) {
                    return@withContext jsCmd // C'est bon, c'est le m3u8 du replay
                }

                // Si flux indisponible (cmd vide), refais handshake et retente une fois
                if (jsCmd.isEmpty() && attempt == 0) {
                    val retryToken = doHandshakeFoxBleu(mac, portalUrl)
                    if (retryToken.isNotEmpty()) {
                        currentToken = retryToken
                    }
                    Log.d("FOX_REPLAY", "cmd vide -> re-handshake et retry")
                }
            } catch (e: Exception) {
                Log.e("FOX_REPLAY", "Tentative $attempt erreur: ${e.message}")
            }
        }

        "" // Vraiment bloqué
    }

    suspend fun getReplayUrl_VRAI_REPLAY(
        mac: String,
        token: String,
        chId: String,
        epgStartTimeString: String, // "2026-07-29 05:50:00" de ton EPG
        epgDuration: Int, // 3900 pour TFou, en secondes
        portalUrl: String = "http://foxbleu.pro/c/",
        archiveTimestampParam: Long = 0L
    ): String? = withContext(Dispatchers.IO) {
        try {
            var currentToken = token
            if (isTokenOld(mac, currentToken)) {
                val freshToken = doHandshakeFoxBleu(mac, portalUrl)
                if (freshToken.isNotEmpty()) {
                    currentToken = freshToken
                }
            }

            // 1. Convertis l'heure EPG "2026-07-29 05:50:00" en timestamp GMT exact
            // Ton EPG est en Europe/Paris, le serveur veut en UTC
            var archiveTimestamp = archiveTimestampParam
            if (epgStartTimeString.isNotEmpty()) {
                try {
                    val parisFormat = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.FRANCE)
                    parisFormat.timeZone = java.util.TimeZone.getTimeZone("Europe/Paris")
                    val date = parisFormat.parse(epgStartTimeString)
                    if (date != null) {
                        archiveTimestamp = (date.time / 1000L) // Timestamp GMT que veut foxbleu
                    }
                } catch (e: Exception) {
                    Log.e("FOX_REPLAY_VRAI", "Erreur parse EPG time: ${e.message}")
                }
            }
            if (archiveTimestamp <= 0L) {
                val num = epgStartTimeString.toLongOrNull()
                if (num != null) {
                    archiveTimestamp = if (num > 100000000000L) num / 1000L else num
                }
            }

            // 2. Duration doit être la vraie durée du programme, pas 3 ou 165
            val duration = epgDuration.coerceAtLeast(60) // en secondes (ex: 3900)

            val cmdEncoded = java.net.URLEncoder.encode("http://localhost/ch/${chId}_", "UTF-8")

            val baseRoot = portalUrl.substringBefore("/stalker_portal").substringBefore("/c/").substringBefore("/server")
                .let { if (it.endsWith("/")) it else "$it/" }
            val loadPhpUrl = "${baseRoot}c/server/load.php"

            val urlsToTry = listOf(
                "$loadPhpUrl?type=itv&action=create_link&cmd=$cmdEncoded&archive=$archiveTimestamp&duration=$duration&token=$currentToken&JsHttpRequest=1-xml",
                "${baseRoot}server/load.php?type=itv&action=create_link&cmd=$cmdEncoded&archive=$archiveTimestamp&duration=$duration&token=$currentToken&JsHttpRequest=1-xml",
                "http://foxbleu.pro/c/server/load.php?type=itv&action=create_link&cmd=$cmdEncoded&archive=$archiveTimestamp&duration=$duration&token=$currentToken&JsHttpRequest=1-xml"
            ).distinct()

            val client = getUnsafeOkHttpClient()

            for (url in urlsToTry) {
                try {
                    Log.e("FOX_REPLAY_VRAI", "ARCHIVE GMT: $archiveTimestamp DURATION: $duration")
                    Log.e("FOX_REPLAY_VRAI", "URL: $url")

                    val req = Request.Builder()
                        .url(url)
                        .get()
                        .header("Cookie", "mac=$mac; stb_lang=en; timezone=Europe/Paris; token=$currentToken")
                        .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                        .header("Referer", "${baseRoot}c/")
                        .build()

                    val body = client.newCall(req).execute().body?.string() ?: continue
                    Log.e("FOX_REPLAY_VRAI", "REPONSE: $body")

                    val cleaned = cleanStalkerJson(body)
                    val json = try { JSONObject(cleaned) } catch (e: Exception) { null }
                    val jsCmd = json?.optJSONObject("js")?.optString("cmd") ?: ""

                    if (jsCmd.isNotBlank()) {
                        val finalUrl = jsCmd.removePrefix("ffmpeg ").removePrefix("ffrt ").removePrefix("auto ").trim()
                        // La réponse doit contenir &archive= dans le play_token si c'est un vrai replay
                        // Si la réponse est juste /play/live.php?stream=13847 sans archive dedans, c'est le LIVE
                        val lower = finalUrl.lowercase()
                        val isVraiReplay = lower.contains("archive") ||
                                lower.contains("timeshift") ||
                                lower.contains("utc=") ||
                                lower.contains("lutc=") ||
                                lower.contains("duration=") ||
                                lower.contains("/media/") ||
                                lower.contains("/archive/") ||
                                lower.contains("/replay/") ||
                                lower.contains("/catchup/")
                        if (isVraiReplay) {
                            Log.e("FOX_REPLAY_VRAI", "VRAI REPLAY VALIDE: $finalUrl")
                            return@withContext finalUrl
                        } else {
                            Log.e("FOX_REPLAY_VRAI", "Lien retourné sans archive= -> C'EST LE LIVE (pas un vrai replay), ignoré: $finalUrl")
                        }
                    }
                } catch (e: Exception) {
                    Log.e("FOX_REPLAY_VRAI", "Erreur tentative $url : ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.e("FOX_REPLAY_VRAI", "Erreur globale: ${e.message}")
        }
        null
    }

    suspend fun getReplayUrl_FoxBleu_Final(
        mac: String,
        token: String,
        epg: EpgFoxBleu,
        portalUrl: String = "http://foxbleu.pro/c/"
    ): String? {
        val durationSec = (epg.stop_timestamp - epg.start_timestamp).toInt().coerceAtLeast(60)
        return getReplayUrl_VRAI_REPLAY(
            mac = mac,
            token = token,
            chId = epg.ch_id,
            epgStartTimeString = "",
            epgDuration = durationSec,
            portalUrl = portalUrl,
            archiveTimestampParam = epg.start_timestamp
        )
    }
}
