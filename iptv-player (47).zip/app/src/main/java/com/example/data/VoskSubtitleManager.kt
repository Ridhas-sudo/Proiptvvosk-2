package com.example.data

import android.content.Context
import android.util.Log
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import com.example.debug.GlobalDebugSystem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.TimeUnit

/**
 * Informations sur un modèle vocal Vosk hors-ligne
 */
data class VoskModelInfo(
    val id: String,
    val code: String,
    val name: String,
    val size: String,
    val baseUrl: String,
    val dirName: String,
    val fileNames: List<String> = emptyList()
) {
    val displayName: String get() = name
    val sizeDescription: String get() = size
}

typealias SherpaModelInfo = VoskModelInfo

/**
 * Gestionnaire du flux audio et de la reconnaissance vocale Vosk hors-ligne
 */
object VoskSubtitleManager {

    private const val TAG = "VoskSubtitleManager"
    private const val SAMPLE_RATE = 16000
    private const val CHANNELS = 1

    val AVAILABLE_MODELS: List<VoskModelInfo> = listOf(
        VoskModelInfo(
            id = "fr",
            code = "fr",
            name = "Français (Vosk)",
            size = "~40 Mo",
            baseUrl = "https://alphacephei.com/vosk/models/vosk-model-small-fr-0.22.zip",
            dirName = "vosk-model-small-fr-0.22"
        ),
        VoskModelInfo(
            id = "en",
            code = "en",
            name = "Anglais (Vosk)",
            size = "~40 Mo",
            baseUrl = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip",
            dirName = "vosk-model-small-en-us-0.15"
        ),
        VoskModelInfo(
            id = "ar",
            code = "ar",
            name = "Arabe (Vosk)",
            size = "~35 Mo",
            baseUrl = "https://alphacephei.com/vosk/models/vosk-model-ar-mgb2-0.4.zip",
            dirName = "vosk-model-ar-mgb2-0.4"
        ),
        VoskModelInfo(
            id = "es",
            code = "es",
            name = "Espagnol (Vosk)",
            size = "~39 Mo",
            baseUrl = "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip",
            dirName = "vosk-model-small-es-0.42"
        ),
        VoskModelInfo(
            id = "de",
            code = "de",
            name = "Allemand (Vosk)",
            size = "~45 Mo",
            baseUrl = "https://alphacephei.com/vosk/models/vosk-model-small-de-0.15.zip",
            dirName = "vosk-model-small-de-0.15"
        ),
        VoskModelInfo(
            id = "it",
            code = "it",
            name = "Italien (Vosk)",
            size = "~45 Mo",
            baseUrl = "https://alphacephei.com/vosk/models/vosk-model-small-it-0.22.zip",
            dirName = "vosk-model-small-it-0.22"
        ),
        VoskModelInfo(
            id = "pt",
            code = "pt",
            name = "Portugais (Vosk)",
            size = "~31 Mo",
            baseUrl = "https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip",
            dirName = "vosk-model-small-pt-0.3"
        ),
        VoskModelInfo(
            id = "ru",
            code = "ru",
            name = "Russe (Vosk)",
            size = "~45 Mo",
            baseUrl = "https://alphacephei.com/vosk/models/vosk-model-small-ru-0.22.zip",
            dirName = "vosk-model-small-ru-0.22"
        ),
        VoskModelInfo(
            id = "tr",
            code = "tr",
            name = "Turc (Vosk)",
            size = "~35 Mo",
            baseUrl = "https://alphacephei.com/vosk/models/vosk-model-small-tr-0.3.zip",
            dirName = "vosk-model-small-tr-0.3"
        )
    )

    val allModels: List<VoskModelInfo> = AVAILABLE_MODELS

    private val _isVoiceRecognitionActive = MutableStateFlow(false)
    val isVoiceRecognitionActive: StateFlow<Boolean> = _isVoiceRecognitionActive.asStateFlow()

    private val _selectedVoiceModelId = MutableStateFlow("auto")
    val selectedVoiceModelId: StateFlow<String> = _selectedVoiceModelId.asStateFlow()

    private val _isDownloadingModel = MutableStateFlow(false)
    val isDownloadingModel: StateFlow<Boolean> = _isDownloadingModel.asStateFlow()

    private val _downloadProgress = MutableStateFlow(0f)
    val downloadProgress: StateFlow<Float> = _downloadProgress.asStateFlow()

    private val _downloadStatusMessage = MutableStateFlow<String?>(null)
    val downloadStatusMessage: StateFlow<String?> = _downloadStatusMessage.asStateFlow()

    private val _isSpeechDetected = MutableStateFlow(false)
    val isSpeechDetected: StateFlow<Boolean> = _isSpeechDetected.asStateFlow()

    private val _autoCalibratedOffsetMs = MutableStateFlow(0)
    val autoCalibratedOffsetMs: StateFlow<Int> = _autoCalibratedOffsetMs.asStateFlow()

    private var onSpeechResultListener: ((String) -> Unit)? = null
    private var onPartialListener: ((String) -> Unit)? = null
    private var onFinalListener: ((String, Long, Long) -> Unit)? = null

    private val audioChannel = Channel<ByteArray>(capacity = 64, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var currentModel: Model? = null
    private var currentRecognizer: Recognizer? = null
    private val recognizerMutex = Mutex()

    private var processingJob: Job? = null
    private var autoClearJob: Job? = null
    private var syncOffsetMs = 0
    private var autoClearDelaySecs = 6
    private var streamingMode = true
    private var intelligentDuration = true
    private var autoCalibration = true

    fun initialize(context: Context) {
        Log.d(TAG, "VoskSubtitleManager initialized")
    }

    fun setOnSpeechResultListener(listener: ((String) -> Unit)?) {
        this.onSpeechResultListener = listener
    }

    fun setOnPartialListener(listener: ((String) -> Unit)?) {
        this.onPartialListener = listener
    }

    fun setOnFinalListener(listener: ((String, Long, Long) -> Unit)?) {
        this.onFinalListener = listener
    }

    fun setSelectedVoiceModelId(id: String) {
        _selectedVoiceModelId.value = id
    }

    fun setSyncOffsetMs(offset: Int) {
        this.syncOffsetMs = offset
    }

    fun setAutoCalibrationEnabled(enabled: Boolean) {
        this.autoCalibration = enabled
    }

    fun setAutoClearDelaySeconds(seconds: Int) {
        this.autoClearDelaySecs = seconds
    }

    fun setIntelligentDurationEnabled(enabled: Boolean) {
        this.intelligentDuration = enabled
    }

    fun setStreamingMode(enabled: Boolean) {
        this.streamingMode = enabled
    }

    fun startVoiceRecognition(context: Context) {
        _isVoiceRecognitionActive.value = true
        startAudioProcessingLoop(context)
    }

    fun stopVoiceRecognition() {
        _isVoiceRecognitionActive.value = false
        _isSpeechDetected.value = false
        processingJob?.cancel()
        processingJob = null
        autoClearJob?.cancel()
        autoClearJob = null
    }

    fun setSourceLanguage(langCode: String, context: Context) {
        _selectedVoiceModelId.value = langCode
        scope.launch(Dispatchers.IO) {
            loadModelForLanguage(langCode, context)
        }
    }

    fun resetRecognitionState() {
        _isSpeechDetected.value = false
        autoClearJob?.cancel()
        autoClearJob = null
    }

    fun flushAccumulator() {
        // Buffer flush
    }

    fun refreshAutoClearTimer(text: String) {
        autoClearJob?.cancel()
        val delayMs = (autoClearDelaySecs * 1000L).coerceAtLeast(2000L)
        autoClearJob = scope.launch {
            delay(delayMs)
            onSpeechResultListener?.invoke("")
        }
    }

    fun injectSimulationSpeech(phrase: String) {
        scope.launch {
            onPartialListener?.invoke(phrase)
            delay(500)
            onSpeechResultListener?.invoke(phrase)
        }
    }

    fun isModelInstalled(context: Context, modelInfo: VoskModelInfo): Boolean {
        val modelDir = File(context.filesDir, "vosk_models/${modelInfo.dirName}")
        return modelDir.exists() && modelDir.isDirectory && (modelDir.listFiles()?.isNotEmpty() == true)
    }

    suspend fun downloadAndExtractModel(context: Context, modelInfo: VoskModelInfo): Boolean = withContext(Dispatchers.IO) {
        try {
            _isDownloadingModel.value = true
            _downloadProgress.value = 0.05f
            _downloadStatusMessage.value = "Téléchargement du modèle ${modelInfo.displayName}..."

            val baseDir = File(context.filesDir, "vosk_models")
            baseDir.mkdirs()
            val zipFile = File(baseDir, "${modelInfo.dirName}.zip")

            val client = OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .build()

            val request = Request.Builder().url(modelInfo.baseUrl).build()
            val response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                _downloadStatusMessage.value = "Erreur HTTP ${response.code}"
                _isDownloadingModel.value = false
                return@withContext false
            }

            val body = response.body ?: return@withContext false
            val totalBytes = body.contentLength()
            var bytesCopied = 0L

            body.byteStream().use { input ->
                FileOutputStream(zipFile).use { output ->
                    val buffer = ByteArray(8192)
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        output.write(buffer, 0, read)
                        bytesCopied += read
                        if (totalBytes > 0) {
                            _downloadProgress.value = (bytesCopied.toFloat() / totalBytes.toFloat()) * 0.8f
                        }
                    }
                }
            }

            _downloadStatusMessage.value = "Extraction du modèle..."
            _downloadProgress.value = 0.85f

            java.util.zip.ZipInputStream(zipFile.inputStream()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val newFile = File(baseDir, entry.name)
                    if (entry.isDirectory) {
                        newFile.mkdirs()
                    } else {
                        newFile.parentFile?.mkdirs()
                        FileOutputStream(newFile).use { fos ->
                            zis.copyTo(fos)
                        }
                    }
                    entry = zis.nextEntry
                }
            }

            zipFile.delete()
            _downloadProgress.value = 1f
            _downloadStatusMessage.value = "Modèle prêt !"
            _isDownloadingModel.value = false
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed downloading model: ${e.message}", e)
            _downloadStatusMessage.value = "Erreur: ${e.message}"
            _isDownloadingModel.value = false
            false
        }
    }

    suspend fun deleteModel(context: Context, modelInfo: VoskModelInfo) = withContext(Dispatchers.IO) {
        val modelDir = File(context.filesDir, "vosk_models/${modelInfo.dirName}")
        if (modelDir.exists()) {
            modelDir.deleteRecursively()
        }
    }

    private suspend fun loadModelForLanguage(langCode: String, context: Context) {
        val modelInfo = AVAILABLE_MODELS.find { it.code.equals(langCode, ignoreCase = true) } 
            ?: AVAILABLE_MODELS.first()

        recognizerMutex.withLock {
            try {
                val modelDir = File(context.filesDir, "vosk_models/${modelInfo.dirName}")
                if (modelDir.exists() && modelDir.isDirectory) {
                    currentRecognizer?.close()
                    currentModel?.close()
                    
                    val model = Model(modelDir.absolutePath)
                    val recognizer = Recognizer(model, SAMPLE_RATE.toFloat())
                    currentModel = model
                    currentRecognizer = recognizer
                    Log.d(TAG, "Loaded Vosk model: ${modelInfo.name}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to load Vosk model: ${e.message}", e)
            }
            Unit
        }
    }

    private fun startAudioProcessingLoop(context: Context) {
        processingJob?.cancel()
        processingJob = scope.launch(Dispatchers.Default) {
            while (isActive && _isVoiceRecognitionActive.value) {
                try {
                    val chunk = audioChannel.receive()
                    recognizerMutex.withLock {
                        val recognizer = currentRecognizer
                        if (recognizer != null) {
                            if (recognizer.acceptWaveForm(chunk, chunk.size)) {
                                val resultJson = recognizer.result
                                val text = parseVoskJsonText(resultJson)
                                if (text.isNotBlank()) {
                                    _isSpeechDetected.value = true
                                    onSpeechResultListener?.invoke(text)
                                    onFinalListener?.invoke(text, System.currentTimeMillis(), System.currentTimeMillis() + 3000L)
                                }
                            } else {
                                val partialJson = recognizer.partialResult
                                val partialText = parseVoskJsonPartial(partialJson)
                                if (partialText.isNotBlank()) {
                                    _isSpeechDetected.value = true
                                    if (streamingMode) {
                                        onPartialListener?.invoke(partialText)
                                    }
                                }
                            }
                        }
                    }
                } catch (e: CancellationException) {
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Error in audio loop: ${e.message}", e)
                }
            }
        }
    }

    private fun parseVoskJsonText(json: String): String {
        return try {
            val idx = json.indexOf("\"text\" : \"")
            if (idx != -1) {
                val start = idx + 10
                val end = json.indexOf("\"", start)
                if (end != -1) json.substring(start, end) else ""
            } else ""
        } catch (e: Exception) {
            ""
        }
    }

    private fun parseVoskJsonPartial(json: String): String {
        return try {
            val idx = json.indexOf("\"partial\" : \"")
            if (idx != -1) {
                val start = idx + 13
                val end = json.indexOf("\"", start)
                if (end != -1) json.substring(start, end) else ""
            } else ""
        } catch (e: Exception) {
            ""
        }
    }

    fun createMedia3AudioProcessor(): AudioProcessor {
        return VoskCaptureAudioProcessor()
    }

    private class VoskCaptureAudioProcessor : BaseAudioProcessor() {
        override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
            return if (inputAudioFormat.encoding == C.ENCODING_PCM_16BIT) {
                inputAudioFormat
            } else {
                AudioProcessor.AudioFormat.NOT_SET
            }
        }

        override fun queueInput(inputBuffer: ByteBuffer) {
            val remaining = inputBuffer.remaining()
            if (remaining == 0) return

            // 1. Pass through audio to downstream AudioSink (AudioTrack) so audio plays and video clock advances smoothly
            val out = replaceOutputBuffer(remaining)
            val dup = inputBuffer.duplicate()
            out.put(dup)
            out.flip()

            // 2. If voice recognition is active, tap audio for Vosk recognition
            if (_isVoiceRecognitionActive.value) {
                val bytes = ByteArray(remaining)
                inputBuffer.get(bytes)
                audioChannel.trySend(bytes)
            } else {
                inputBuffer.position(inputBuffer.limit())
            }
        }
    }
}

/**
 * Objet d'alias pour la compatibilité avec l'ensemble du projet
 */
object SherpaSubtitleManager {
    val AVAILABLE_MODELS get() = VoskSubtitleManager.AVAILABLE_MODELS
    val allModels get() = VoskSubtitleManager.allModels
    val isVoiceRecognitionActive get() = VoskSubtitleManager.isVoiceRecognitionActive
    val selectedVoiceModelId get() = VoskSubtitleManager.selectedVoiceModelId
    val isDownloadingModel get() = VoskSubtitleManager.isDownloadingModel
    val downloadProgress get() = VoskSubtitleManager.downloadProgress
    val downloadStatusMessage get() = VoskSubtitleManager.downloadStatusMessage
    val isSpeechDetected get() = VoskSubtitleManager.isSpeechDetected
    val autoCalibratedOffsetMs get() = VoskSubtitleManager.autoCalibratedOffsetMs

    fun initialize(context: Context) = VoskSubtitleManager.initialize(context)
    fun setOnSpeechResultListener(listener: ((String) -> Unit)?) = VoskSubtitleManager.setOnSpeechResultListener(listener)
    fun setOnPartialListener(listener: ((String) -> Unit)?) = VoskSubtitleManager.setOnPartialListener(listener)
    fun setOnFinalListener(listener: ((String, Long, Long) -> Unit)?) = VoskSubtitleManager.setOnFinalListener(listener)
    fun setSelectedVoiceModelId(id: String) = VoskSubtitleManager.setSelectedVoiceModelId(id)
    fun setSyncOffsetMs(offset: Int) = VoskSubtitleManager.setSyncOffsetMs(offset)
    fun setAutoCalibrationEnabled(enabled: Boolean) = VoskSubtitleManager.setAutoCalibrationEnabled(enabled)
    fun setAutoClearDelaySeconds(seconds: Int) = VoskSubtitleManager.setAutoClearDelaySeconds(seconds)
    fun setIntelligentDurationEnabled(enabled: Boolean) = VoskSubtitleManager.setIntelligentDurationEnabled(enabled)
    fun setStreamingMode(enabled: Boolean) = VoskSubtitleManager.setStreamingMode(enabled)
    fun startVoiceRecognition(context: Context) = VoskSubtitleManager.startVoiceRecognition(context)
    fun stopVoiceRecognition() = VoskSubtitleManager.stopVoiceRecognition()
    fun setSourceLanguage(langCode: String, context: Context) = VoskSubtitleManager.setSourceLanguage(langCode, context)
    fun resetRecognitionState() = VoskSubtitleManager.resetRecognitionState()
    fun flushAccumulator() = VoskSubtitleManager.flushAccumulator()
    fun refreshAutoClearTimer(text: String) = VoskSubtitleManager.refreshAutoClearTimer(text)
    fun injectSimulationSpeech(phrase: String) = VoskSubtitleManager.injectSimulationSpeech(phrase)
    fun isModelInstalled(context: Context, modelInfo: VoskModelInfo) = VoskSubtitleManager.isModelInstalled(context, modelInfo)
    suspend fun downloadAndExtractModel(context: Context, modelInfo: VoskModelInfo) = VoskSubtitleManager.downloadAndExtractModel(context, modelInfo)
    suspend fun deleteModel(context: Context, modelInfo: VoskModelInfo) = VoskSubtitleManager.deleteModel(context, modelInfo)
    fun createMedia3AudioProcessor() = VoskSubtitleManager.createMedia3AudioProcessor()
}
