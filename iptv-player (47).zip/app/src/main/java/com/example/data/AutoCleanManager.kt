package com.example.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Gestionnaire autonome d'auto-nettoyage et d'optimisation de performance.
 * Maintient l'application ultra-légère, sans accumulation de cache, ni fichiers orphelins,
 * avec compactage périodique de la base de données et libération immédiate de la mémoire RAM.
 */
object AutoCleanManager {
    private const val TAG = "AutoCleanManager"

    data class CleanReport(
        val bytesFreed: Long,
        val orphansRemoved: Int,
        val filesDeleted: Int,
        val isSuccessful: Boolean,
        val summary: String,
        val timestamp: Long = System.currentTimeMillis()
    )

    private val _isCleaning = MutableStateFlow(false)
    val isCleaning: StateFlow<Boolean> = _isCleaning.asStateFlow()

    private val _lastReport = MutableStateFlow<CleanReport?>(null)
    val lastReport: StateFlow<CleanReport?> = _lastReport.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.IO)

    /**
     * Lance un nettoyage automatique discret en arrière-plan sans bloquer l'UI.
     */
    fun triggerAutoClean(context: Context, deepClean: Boolean = false, onFinished: ((CleanReport) -> Unit)? = null) {
        if (_isCleaning.value) return
        scope.launch {
            val report = executeClean(context.applicationContext, deepClean)
            _lastReport.value = report
            withContext(Dispatchers.Main) {
                onFinished?.invoke(report)
            }
        }
    }

    /**
     * Calcule la taille totale actuelle des répertoires de cache de l'application.
     */
    fun calculateTotalCacheSize(context: Context): Long {
        var total = 0L
        try {
            total += getFolderSize(context.cacheDir)
            context.externalCacheDir?.let { total += getFolderSize(it) }
            total += getFolderSize(File(context.filesDir, "logs"))
            total += getFolderSize(File(context.filesDir, "temp"))
        } catch (e: Exception) {
            Log.w(TAG, "Erreur calcul taille cache: ${e.message}")
        }
        return total
    }

    private fun getFolderSize(dir: File?): Long {
        if (dir == null || !dir.exists()) return 0L
        var size = 0L
        val files = dir.listFiles() ?: return 0L
        for (f in files) {
            size += if (f.isDirectory) getFolderSize(f) else f.length()
        }
        return size
    }

    private suspend fun executeClean(context: Context, deepClean: Boolean): CleanReport = withContext(Dispatchers.IO) {
        _isCleaning.value = true
        var bytesFreed = 0L
        var filesDeleted = 0
        var orphansRemoved = 0

        try {
            val beforeCacheSize = calculateTotalCacheSize(context)

            // 1. Nettoyage des fichiers temporaires, téléchargements incomplets, segments vidéo et logs obsolètes
            filesDeleted += cleanDirectory(context.cacheDir, maxAgeMs = if (deepClean) 0L else 3600_000L)
            context.externalCacheDir?.let {
                filesDeleted += cleanDirectory(it, maxAgeMs = if (deepClean) 0L else 3600_000L)
            }

            // Nettoyage des fichiers temporaires dans filesDir
            val tempDir = File(context.filesDir, "temp")
            if (tempDir.exists()) {
                filesDeleted += cleanDirectory(tempDir, maxAgeMs = 0L)
            }

            // Nettoyer les logs de crash plus vieux que 24h
            val logsDir = File(context.filesDir, "logs")
            if (logsDir.exists()) {
                filesDeleted += cleanDirectory(logsDir, maxAgeMs = 24 * 3600_000L)
            }

            // 2. Nettoyage et compactage de la base de données Room / SQLite
            try {
                val db = AppDatabase.getDatabase(context)
                orphansRemoved = db.cleanOrphanData()
                db.epgCacheDao().clearOldEpg(olderThanMs = if (deepClean) 12 * 3600_000L else 48 * 3600_000L)
                db.rawCacheDao().clearAll()
                db.vacuumDatabase()
            } catch (e: Exception) {
                Log.w(TAG, "Erreur optimisation base de données: ${e.message}")
            }

            // 3. Libération de la mémoire vive (caches légers)
            try {
                TranslationManager.clearCache()
            } catch (e: Exception) {
                // Ignore
            }

            // Calcul du gain
            val afterCacheSize = calculateTotalCacheSize(context)
            val directFreed = (beforeCacheSize - afterCacheSize).coerceAtLeast(0L)
            bytesFreed = if (directFreed > 0) directFreed else (filesDeleted * 4096L)

            // Appel au Garbage Collector pour désencombrer la RAM
            System.gc()

            val formattedSize = formatBytes(bytesFreed)
            val summary = "Optimisation réussie : $formattedSize libérés, $filesDeleted fichiers temporaires purgés, $orphansRemoved entrées orphelines nettoyées."
            Log.i(TAG, summary)

            CleanReport(
                bytesFreed = bytesFreed,
                orphansRemoved = orphansRemoved,
                filesDeleted = filesDeleted,
                isSuccessful = true,
                summary = summary
            )
        } catch (e: Exception) {
            Log.e(TAG, "Erreur lors du nettoyage: ${e.message}", e)
            CleanReport(
                bytesFreed = 0L,
                orphansRemoved = 0,
                filesDeleted = 0,
                isSuccessful = false,
                summary = "Erreur nettoyage: ${e.message}"
            )
        } finally {
            _isCleaning.value = false
        }
    }

    private fun cleanDirectory(dir: File?, maxAgeMs: Long): Int {
        if (dir == null || !dir.exists()) return 0
        var count = 0
        val now = System.currentTimeMillis()
        val files = dir.listFiles() ?: return 0

        for (f in files) {
            if (f.isDirectory) {
                count += cleanDirectory(f, maxAgeMs)
                if (f.listFiles()?.isEmpty() == true) {
                    f.delete()
                }
            } else {
                val isOld = (now - f.lastModified()) >= maxAgeMs
                val isTemp = f.name.endsWith(".tmp", ignoreCase = true) ||
                        f.name.endsWith(".temp", ignoreCase = true) ||
                        f.name.endsWith(".part", ignoreCase = true) ||
                        f.name.endsWith(".bak", ignoreCase = true) ||
                        f.name.startsWith("cache_", ignoreCase = true)

                if (isOld || isTemp) {
                    if (f.delete()) {
                        count++
                    }
                }
            }
        }
        return count
    }

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 Ko"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1.0 -> String.format(java.util.Locale.US, "%.2f Go", gb)
            mb >= 1.0 -> String.format(java.util.Locale.US, "%.1f Mo", mb)
            else -> String.format(java.util.Locale.US, "%.0f Ko", kb.coerceAtLeast(1.0))
        }
    }
}
