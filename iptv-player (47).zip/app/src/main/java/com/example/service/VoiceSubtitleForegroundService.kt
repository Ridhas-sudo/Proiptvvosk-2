package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity

/**
 * Foreground Service minimal pour maintenir le traitement de reconnaissance vocale des sous-titres
 * actif sur Android TV et smartphones Android sans être tué par le système en arrière-plan.
 */
class VoiceSubtitleForegroundService : Service() {

    companion object {
        private const val TAG = "VoiceSubtitleService"
        const val CHANNEL_ID = "voice_subtitle_service_channel"
        const val NOTIFICATION_ID = 10042

        const val ACTION_START = "com.example.service.ACTION_START_VOICE_SUBTITLES"
        const val ACTION_STOP = "com.example.service.ACTION_STOP_VOICE_SUBTITLES"

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(context: Context) {
            try {
                val intent = Intent(context, VoiceSubtitleForegroundService::class.java).apply {
                    action = ACTION_START
                }
                ContextCompat.startForegroundService(context, intent)
                Log.d(TAG, "VoiceSubtitleForegroundService start requested")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start VoiceSubtitleForegroundService: ${e.message}", e)
            }
        }

        fun stop(context: Context) {
            try {
                val intent = Intent(context, VoiceSubtitleForegroundService::class.java).apply {
                    action = ACTION_STOP
                }
                context.startService(intent)
                Log.d(TAG, "VoiceSubtitleForegroundService stop requested")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to stop VoiceSubtitleForegroundService: ${e.message}", e)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START
        if (action == ACTION_STOP) {
            stopForegroundService()
            return START_NOT_STICKY
        }

        try {
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            isRunning = true
            Log.d(TAG, "VoiceSubtitleForegroundService started in foreground")
        } catch (e: Exception) {
            Log.e(TAG, "Error in startForeground: ${e.message}", e)
            try {
                startForeground(NOTIFICATION_ID, buildNotification())
                isRunning = true
            } catch (fallbackEx: Exception) {
                Log.e(TAG, "Fallback startForeground failed: ${fallbackEx.message}", fallbackEx)
            }
        }

        return START_STICKY
    }

    private fun stopForegroundService() {
        isRunning = false
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
            Log.d(TAG, "VoiceSubtitleForegroundService stopped cleanly")
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping foreground service: ${e.message}", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Sous-titres vocaux",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Traitement en arrière-plan des sous-titres vocaux"
                setShowBadge(false)
                enableLights(false)
                enableVibration(false)
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Pro IPTV")
            .setContentText("Sous-titres vocaux actifs")
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(pendingIntent)
            .build()
    }

    override fun onDestroy() {
        isRunning = false
        super.onDestroy()
        Log.d(TAG, "VoiceSubtitleForegroundService destroyed")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
